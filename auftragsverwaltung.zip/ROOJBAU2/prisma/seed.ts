import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

async function main() {
  // Beispiel-Firmen erstellen
  const firma1 = await prisma.firma.create({
    data: {
      name: 'TechCorp GmbH',
      adresse: 'Musterstraße 123, 12345 Berlin',
      telefon: '+49 30 12345678',
      email: 'info@techcorp.de',
      website: 'https://techcorp.de',
      notizen: 'Großer IT-Dienstleister, langjähriger Partner',
    },
  })

  const firma2 = await prisma.firma.create({
    data: {
      name: 'StartUp Solutions',
      adresse: 'Innovationsallee 456, 80331 München',
      telefon: '+49 89 87654321',
      email: 'kontakt@startup-solutions.de',
      website: 'https://startup-solutions.de',
      notizen: 'Junges Unternehmen, sehr agil und innovativ',
    },
  })

  // Projektleiter erstellen
  const projektleiter1 = await prisma.projektleiter.create({
    data: {
      vorname: 'Max',
      nachname: 'Mustermann',
      telefon: '+49 30 11111111',
      email: 'max.mustermann@techcorp.de',
      position: 'Senior Projektmanager',
      notizen: 'Sehr erfahren, technisch versiert',
      firmaId: firma1.id,
    },
  })

  const projektleiter2 = await prisma.projektleiter.create({
    data: {
      vorname: 'Anna',
      nachname: 'Schmidt',
      telefon: '+49 89 22222222',
      email: 'anna.schmidt@startup-solutions.de',
      position: 'CTO',
      notizen: 'Direkte Entscheidungsträgerin, sehr kommunikativ',
      firmaId: firma2.id,
    },
  })

  // Beispiel-Aufträge erstellen
  await prisma.auftrag.create({
    data: {
      auftragsnummer: 'AUF-2024-001',
      titel: 'Website Redesign',
      beschreibung: 'Komplette Überarbeitung der Unternehmenswebsite mit modernem Design und responsivem Layout',
      status: 'IN_BEARBEITUNG',
      prioritaet: 'HOCH',
      startdatum: new Date('2024-01-15'),
      geplantesEnddatum: new Date('2024-03-15'),
      geschaetzterAufwand: 120,
      kosten: 15000,
      firmaId: firma1.id,
      projektleiterId: projektleiter1.id,
      notizen: 'Wichtiger Auftrag für Q1 2024',
    },
  })

  await prisma.auftrag.create({
    data: {
      auftragsnummer: 'AUF-2024-002',
      titel: 'Mobile App Entwicklung',
      beschreibung: 'Entwicklung einer nativen iOS und Android App für Kundenverwaltung',
      status: 'NEU',
      prioritaet: 'NORMAL',
      startdatum: new Date('2024-02-01'),
      geplantesEnddatum: new Date('2024-05-01'),
      geschaetzterAufwand: 200,
      kosten: 25000,
      firmaId: firma2.id,
      projektleiterId: projektleiter2.id,
      notizen: 'Innovative App-Lösung für StartUp',
    },
  })

  console.log('Seed-Daten erfolgreich erstellt!')
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })


'use client'

import { useState } from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Plus, Phone, Mail, User, MessageCircle, Clock, Trash2, Edit, Building, MapPin } from 'lucide-react'

interface Telefonnummer {
  id: string
  nummer: string
  typ?: string
  notizen?: string
}

interface Kontaktperson {
  id: string
  vorname: string
  nachname: string
  position?: string
  abteilung?: string
  etage?: string
  raum?: string
  email?: string
  notizen?: string
  telefonnummern: Telefonnummer[]
  kommunikationen: Kommunikation[]
}

interface Kommunikation {
  id: string
  typ: string
  richtung: string
  betreff?: string
  inhalt?: string
  datum: string
  dauer?: number
  kontaktperson?: {
    vorname: string
    nachname: string
    position?: string
  }
}

interface KontaktpersonenProps {
  auftragId: string
}

export function Kontaktpersonen({ auftragId }: KontaktpersonenProps) {
  const queryClient = useQueryClient()
  const [showAddForm, setShowAddForm] = useState(false)
  const [showCommunicationForm, setShowCommunicationForm] = useState<string | null>(null)
  const [generalNotes, setGeneralNotes] = useState<string>('') // New state for general notes
  const [newContact, setNewContact] = useState({
    vorname: '',
    nachname: '',
    position: '',
    abteilung: '',
    etage: '',
    raum: '',
    email: '',
    notizen: '',
    telefonnummern: [{ nummer: '', typ: 'Büro', notizen: '' }]
  })
  const [newCommunication, setNewCommunication] = useState({
    typ: 'ANRUF',
    richtung: 'AUSGEHEND',
    betreff: '',
    inhalt: '',
    dauer: ''
  })

  const { data: kontaktpersonen, isLoading } = useQuery({
    queryKey: ['kontaktpersonen', auftragId],
    queryFn: async () => {
      const response = await fetch(`/api/kontaktpersonen?auftragId=${auftragId}`)
      if (!response.ok) throw new Error('Fehler beim Laden')
      return response.json() as Promise<Kontaktperson[]>
    }
  })

  const { data: kommunikationen } = useQuery({
    queryKey: ['kommunikationen', auftragId],
    queryFn: async () => {
      const response = await fetch(`/api/kommunikationen?auftragId=${auftragId}`)
      if (!response.ok) throw new Error('Fehler beim Laden')
      return response.json() as Promise<Kommunikation[]>
    }
  })

  const handleAddContact = async (e: React.FormEvent) => {
    e.preventDefault()
    
    try {
      const response = await fetch('/api/kontaktpersonen', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...newContact,
          auftragId,
          telefonnummern: newContact.telefonnummern.filter(tel => tel.nummer.trim())
        }),
      })

      if (!response.ok) throw new Error('Fehler beim Erstellen')

      queryClient.invalidateQueries({ queryKey: ['kontaktpersonen', auftragId] })
      setShowAddForm(false)
      setNewContact({
        vorname: '',
        nachname: '',
        position: '',
        abteilung: '',
        etage: '',
        raum: '',
        email: '',
        notizen: '',
        telefonnummern: [{ nummer: '', typ: 'Büro', notizen: '' }]
      })
    } catch (error) {
      console.error('Fehler:', error)
    }
  }

  const handleAddCommunication = async (e: React.FormEvent) => {
    e.preventDefault()
    
    try {
      const response = await fetch('/api/kommunikationen', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...newCommunication,
          auftragId,
          kontaktpersonId: showCommunicationForm,
          dauer: newCommunication.dauer ? parseInt(newCommunication.dauer) : undefined
        }),
      })

      if (!response.ok) throw new Error('Fehler beim Erstellen')

      queryClient.invalidateQueries({ queryKey: ['kommunikationen', auftragId] })
      queryClient.invalidateQueries({ queryKey: ['kontaktpersonen', auftragId] })
      setShowCommunicationForm(null)
      setNewCommunication({
        typ: 'ANRUF',
        richtung: 'AUSGEHEND',
        betreff: '',
        inhalt: '',
        dauer: ''
      })
    } catch (error) {
      console.error('Fehler:', error)
    }
  }

  const addTelefonnummer = () => {
    setNewContact(prev => ({
      ...prev,
      telefonnummern: [...prev.telefonnummern, { nummer: '', typ: 'Büro', notizen: '' }]
    }))
  }

  const removeTelefonnummer = (index: number) => {
    setNewContact(prev => ({
      ...prev,
      telefonnummern: prev.telefonnummern.filter((_, i) => i !== index)
    }))
  }

  const updateTelefonnummer = (index: number, field: string, value: string) => {
    setNewContact(prev => ({
      ...prev,
      telefonnummern: prev.telefonnummern.map((tel, i) => 
        i === index ? { ...tel, [field]: value } : tel
      )
    }))
  }

  if (isLoading) {
    return (
      <div className="fintech-card spacing-3">
        <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-cyan-400 mx-auto"></div>
        <p className="body-small text-gray-400 text-center mt-2">Kontakte werden geladen...</p>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Kontaktpersonen */}
      <div className="fintech-card spacing-4 micro-slide-up">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-3">
            <div className="fintech-kpi-card p-3 neon-glow-cyan">
              <User className="h-6 w-6 text-cyan-400" />
            </div>
            <div>
              <h2 className="headline-small font-bold text-white">Kontaktpersonen ({kontaktpersonen?.length || 0})</h2>
              <p className="body-small text-gray-400">Ansprechpartner für diesen Auftrag</p>
            </div>
          </div>
          <button
            onClick={() => setShowAddForm(!showAddForm)}
            className="fintech-button-primary micro-bounce"
          >
            <Plus className="h-4 w-4" />
          </button>
        </div>

        {/* General Notes for Kontaktpersonen */}
        <div className="ios-card spacing-2 mb-6">
          <Label className="label-medium text-gray-900 dark:text-white">Allgemeine Notizen zu Kontaktpersonen</Label>
          <Textarea
            value={generalNotes}
            onChange={(e) => setGeneralNotes(e.target.value)}
            placeholder="Allgemeine Notizen zu den Kontaktpersonen dieses Auftrags..."
            className="mt-1 focus-ring-fintech"
            rows={3}
          />
        </div>

        {/* Add Contact Form */}
        {showAddForm && (
          <div className="m3-card-elevated spacing-3 mb-6">
            <form onSubmit={handleAddContact} className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="ios-card spacing-2">
                  <Label className="label-medium text-gray-900 dark:text-white">Vorname *</Label>
                  <Input
                    value={newContact.vorname}
                    onChange={(e) => setNewContact(prev => ({ ...prev, vorname: e.target.value }))}
                    className="mt-1 focus-ring-fintech"
                    required
                  />
                </div>
                <div className="ios-card spacing-2">
                  <Label className="label-medium text-gray-900 dark:text-white">Nachname *</Label>
                  <Input
                    value={newContact.nachname}
                    onChange={(e) => setNewContact(prev => ({ ...prev, nachname: e.target.value }))}
                    className="mt-1 focus-ring-fintech"
                    required
                  />
                </div>
                <div className="ios-card spacing-2">
                  <Label className="label-medium text-gray-900 dark:text-white">Position</Label>
                  <Input
                    value={newContact.position}
                    onChange={(e) => setNewContact(prev => ({ ...prev, position: e.target.value }))}
                    placeholder="z.B. Projektmanager"
                    className="mt-1 focus-ring-fintech"
                  />
                </div>
                <div className="ios-card spacing-2">
                  <Label className="label-medium text-gray-900 dark:text-white">Abteilung</Label>
                  <Input
                    value={newContact.abteilung}
                    onChange={(e) => setNewContact(prev => ({ ...prev, abteilung: e.target.value }))}
                    placeholder="z.B. IT-Abteilung"
                    className="mt-1 focus-ring-fintech"
                  />
                </div>
                <div className="ios-card spacing-2">
                  <Label className="label-medium text-gray-900 dark:text-white">Etage</Label>
                  <Input
                    value={newContact.etage}
                    onChange={(e) => setNewContact(prev => ({ ...prev, etage: e.target.value }))}
                    placeholder="z.B. 3. OG"
                    className="mt-1 focus-ring-fintech"
                  />
                </div>
                <div className="ios-card spacing-2">
                  <Label className="label-medium text-gray-900 dark:text-white">Raum</Label>
                  <Input
                    value={newContact.raum}
                    onChange={(e) => setNewContact(prev => ({ ...prev, raum: e.target.value }))}
                    placeholder="z.B. Raum 301"
                    className="mt-1 focus-ring-fintech"
                  />
                </div>
                <div className="md:col-span-2 ios-card spacing-2">
                  <Label className="label-medium text-gray-900 dark:text-white">E-Mail</Label>
                  <Input
                    type="email"
                    value={newContact.email}
                    onChange={(e) => setNewContact(prev => ({ ...prev, email: e.target.value }))}
                    placeholder="kontakt@firma.de"
                    className="mt-1 focus-ring-fintech"
                  />
                </div>
              </div>

              {/* Telefonnummern */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label className="label-medium text-gray-900 dark:text-white">Telefonnummern</Label>
                  <button type="button" onClick={addTelefonnummer} className="ios-button-secondary p-2 micro-bounce">
                    <Plus className="h-4 w-4" />
                  </button>
                </div>
                {newContact.telefonnummern.map((tel, index) => (
                  <div key={index} className="ios-card spacing-2">
                    <div className="grid gap-3 md:grid-cols-3">
                      <Input
                        placeholder="Telefonnummer"
                        value={tel.nummer}
                        onChange={(e) => updateTelefonnummer(index, 'nummer', e.target.value)}
                        className="focus-ring-fintech"
                      />
                      <select
                        value={tel.typ}
                        onChange={(e) => updateTelefonnummer(index, 'typ', e.target.value)}
                        className="px-3 py-2 border-2 rounded-xl bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus-ring-fintech"
                      >
                        <option value="Büro">Büro</option>
                        <option value="Mobil">Mobil</option>
                        <option value="Durchwahl">Durchwahl</option>
                        <option value="Fax">Fax</option>
                      </select>
                      <div className="flex space-x-2">
                        <Input
                          placeholder="Notizen"
                          value={tel.notizen}
                          onChange={(e) => updateTelefonnummer(index, 'notizen', e.target.value)}
                          className="focus-ring-fintech"
                        />
                        {newContact.telefonnummern.length > 1 && (
                          <button type="button" onClick={() => removeTelefonnummer(index)} className="ios-button-secondary p-2 text-red-500">
                            <Trash2 className="h-4 w-4" />
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="ios-card spacing-2">
                <Label className="label-medium text-gray-900 dark:text-white">Notizen</Label>
                <Textarea
                  value={newContact.notizen}
                  onChange={(e) => setNewContact(prev => ({ ...prev, notizen: e.target.value }))}
                  placeholder="Zusätzliche Informationen..."
                  className="mt-1 focus-ring-fintech"
                  rows={2}
                />
              </div>

              <div className="flex justify-end space-x-3">
                <button type="button" onClick={() => setShowAddForm(false)} className="ios-button-secondary px-4 py-2 micro-bounce">
                  Abbrechen
                </button>
                <button type="submit" className="fintech-button-primary px-4 py-2 micro-slide-up">
                  <User className="mr-2 h-4 w-4" />
                  Kontakt hinzufügen
                </button>
              </div>
            </form>
          </div>
        )}

        {/* Contact List */}
        <div className="space-y-4">
          {kontaktpersonen?.length === 0 ? (
            <div className="text-center py-8">
              <div className="fintech-kpi-card p-4 mx-auto w-fit mb-4">
                <User className="h-8 w-8 text-cyan-400" />
              </div>
              <p className="body-medium text-gray-400 mb-4">Noch keine Kontaktpersonen</p>
              <button onClick={() => setShowAddForm(true)} className="fintech-button-primary micro-bounce">
                Erste Kontaktperson hinzufügen
              </button>
            </div>
          ) : (
            kontaktpersonen?.map((kontakt) => (
              <div key={kontakt.id} className="m3-card-elevated spacing-3 micro-slide-up">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <h4 className="title-medium font-bold text-gray-900 dark:text-white">
                      {kontakt.vorname} {kontakt.nachname}
                    </h4>
                    <div className="flex flex-wrap gap-2 mt-2">
                      {kontakt.position && (
                        <Badge variant="outline" className="body-small">
                          👤 {kontakt.position}
                        </Badge>
                      )}
                      {kontakt.abteilung && (
                        <Badge variant="outline" className="body-small">
                          🏢 {kontakt.abteilung}
                        </Badge>
                      )}
                      {kontakt.etage && (
                        <Badge variant="outline" className="body-small">
                          🏗️ {kontakt.etage}
                        </Badge>
                      )}
                      {kontakt.raum && (
                        <Badge variant="outline" className="body-small">
                          🚪 {kontakt.raum}
                        </Badge>
                      )}
                    </div>
                  </div>
                  <button
                    onClick={() => setShowCommunicationForm(showCommunicationForm === kontakt.id ? null : kontakt.id)}
                    className="ios-button-secondary p-2 micro-bounce"
                  >
                    <MessageCircle className="h-4 w-4" />
                  </button>
                </div>

                {/* Kontaktinformationen */}
                <div className="grid gap-3 md:grid-cols-2">
                  {kontakt.telefonnummern.map((tel) => (
                    <div key={tel.id} className="flex items-center space-x-2 p-2 bg-gray-50 dark:bg-gray-800/50 rounded-lg">
                      <Phone className="h-4 w-4 text-blue-400" />
                      <div className="flex-1">
                        <span className="body-small font-medium text-gray-900 dark:text-white">{tel.nummer}</span>
                        {tel.typ && <span className="body-small text-gray-500 ml-2">({tel.typ})</span>}
                        {tel.notizen && <p className="body-small text-gray-500">{tel.notizen}</p>}
                      </div>
                    </div>
                  ))}
                  {kontakt.email && (
                    <div className="flex items-center space-x-2 p-2 bg-gray-50 dark:bg-gray-800/50 rounded-lg">
                      <Mail className="h-4 w-4 text-purple-400" />
                      <span className="body-small text-gray-900 dark:text-white">{kontakt.email}</span>
                    </div>
                  )}
                </div>

                {kontakt.notizen && (
                  <div className="mt-3 p-3 bg-gray-50 dark:bg-gray-800/50 rounded-lg">
                    <p className="body-small text-gray-700 dark:text-gray-300">{kontakt.notizen}</p>
                  </div>
                )}

                {/* Communication Form */}
                {showCommunicationForm === kontakt.id && (
                  <div className="mt-4 m3-card-filled spacing-3">
                    <form onSubmit={handleAddCommunication} className="space-y-3">
                      <div className="grid gap-3 md:grid-cols-3">
                        <select
                          value={newCommunication.typ}
                          onChange={(e) => setNewCommunication(prev => ({ ...prev, typ: e.target.value }))}
                          className="px-3 py-2 border-2 rounded-xl bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus-ring-fintech"
                        >
                          <option value="ANRUF">📞 Anruf</option>
                          <option value="EMAIL">📧 E-Mail</option>
                          <option value="MEETING">🤝 Meeting</option>
                          <option value="NOTIZ">📝 Notiz</option>
                        </select>
                        <select
                          value={newCommunication.richtung}
                          onChange={(e) => setNewCommunication(prev => ({ ...prev, richtung: e.target.value }))}
                          className="px-3 py-2 border-2 rounded-xl bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus-ring-fintech"
                        >
                          <option value="AUSGEHEND">📤 Ausgehend</option>
                          <option value="EINGEHEND">📥 Eingehend</option>
                        </select>
                        {(newCommunication.typ === 'ANRUF' || newCommunication.typ === 'MEETING') && (
                          <Input
                            type="number"
                            placeholder="Dauer (Min)"
                            value={newCommunication.dauer}
                            onChange={(e) => setNewCommunication(prev => ({ ...prev, dauer: e.target.value }))}
                            className="focus-ring-fintech"
                          />
                        )}
                      </div>
                      <Input
                        placeholder="Betreff"
                        value={newCommunication.betreff}
                        onChange={(e) => setNewCommunication(prev => ({ ...prev, betreff: e.target.value }))}
                        className="focus-ring-fintech"
                      />
                      <Textarea
                        placeholder="Inhalt der Kommunikation..."
                        value={newCommunication.inhalt}
                        onChange={(e) => setNewCommunication(prev => ({ ...prev, inhalt: e.target.value }))}
                        className="focus-ring-fintech"
                        rows={3}
                      />
                      <div className="flex justify-end space-x-2">
                        <button type="button" onClick={() => setShowCommunicationForm(null)} className="ios-button-secondary px-3 py-2">
                          Abbrechen
                        </button>
                        <button type="submit" className="fintech-button-primary px-3 py-2">
                          <MessageCircle className="mr-2 h-4 w-4" />
                          Hinzufügen
                        </button>
                      </div>
                    </form>
                  </div>
                )}

                {/* Recent Communications for this contact */}
                {kontakt.kommunikationen?.length > 0 && (
                  <div className="mt-4 space-y-2">
                    <p className="label-small text-gray-400 uppercase tracking-widest">Letzte Kommunikation</p>
                    {kontakt.kommunikationen.slice(0, 2).map((komm) => (
                      <div key={komm.id} className="flex items-center space-x-3 p-2 bg-white/5 rounded-lg">
                        <div className="fintech-kpi-card p-1">
                          {komm.typ === 'ANRUF' && <Phone className="h-3 w-3 text-blue-400" />}
                          {komm.typ === 'EMAIL' && <Mail className="h-3 w-3 text-purple-400" />}
                          {komm.typ === 'MEETING' && <User className="h-3 w-3 text-green-400" />}
                          {komm.typ === 'NOTIZ' && <MessageCircle className="h-3 w-3 text-orange-400" />}
                        </div>
                        <div className="flex-1">
                          <p className="body-small text-white">{komm.betreff || komm.typ}</p>
                          <p className="body-small text-gray-400">{new Date(komm.datum).toLocaleDateString('de-DE')}</p>
                        </div>
                        {komm.dauer && (
                          <span className="label-small text-gray-400">{komm.dauer}min</span>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      </div>

      {/* Kommunikationshistorie */}
      <div className="m3-card-elevated spacing-4 micro-slide-up">
        <div className="flex items-center space-x-3 mb-6">
          <div className="fintech-kpi-card p-3 neon-glow-blue">
            <MessageCircle className="h-6 w-6 text-blue-400" />
          </div>
          <div>
            <h2 className="headline-small font-bold text-gray-900 dark:text-white">Kommunikationshistorie</h2>
            <p className="body-small text-gray-600 dark:text-gray-400">Alle Kontakte und Gespräche</p>
          </div>
        </div>

        <div className="space-y-3">
          {kommunikationen?.length === 0 ? (
            <p className="body-medium text-gray-600 dark:text-gray-400 text-center py-4">
              Noch keine Kommunikation erfasst
            </p>
          ) : (
            kommunikationen?.map((komm) => (
              <div key={komm.id} className="flex items-start space-x-3 p-3 bg-gray-50 dark:bg-gray-800/50 rounded-xl hover:bg-gray-100 dark:hover:bg-gray-700/50 transition-all">
                <div className="fintech-kpi-card p-2">
                  {komm.typ === 'ANRUF' && <Phone className="h-4 w-4 text-blue-400" />}
                  {komm.typ === 'EMAIL' && <Mail className="h-4 w-4 text-purple-400" />}
                  {komm.typ === 'MEETING' && <User className="h-4 w-4 text-green-400" />}
                  {komm.typ === 'NOTIZ' && <MessageCircle className="h-4 w-4 text-orange-400" />}
                </div>
                <div className="flex-1">
                  <div className="flex items-center space-x-2 mb-1">
                    <h5 className="title-small font-bold text-gray-900 dark:text-white">
                      {komm.betreff || komm.typ}
                    </h5>
                    <Badge variant="outline" className={komm.richtung === 'EINGEHEND' ? 'text-green-600' : 'text-blue-600'}>
                      {komm.richtung === 'EINGEHEND' ? '📥 Eingehend' : '📤 Ausgehend'}
                    </Badge>
                  </div>
                  {komm.kontaktperson && (
                    <p className="body-small text-gray-600 dark:text-gray-400 mb-1">
                      mit {komm.kontaktperson.vorname} {komm.kontaktperson.nachname}
                      {komm.kontaktperson.position && ` (${komm.kontaktperson.position})`}
                    </p>
                  )}
                  {komm.inhalt && (
                    <p className="body-small text-gray-700 dark:text-gray-300 mb-2">{komm.inhalt}</p>
                  )}
                  <div className="flex items-center space-x-4 text-xs text-gray-500">
                    <span>{new Date(komm.datum).toLocaleString('de-DE')}</span>
                    {komm.dauer && <span>⏱️ {komm.dauer} Min</span>}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  )
}

'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { cn } from '@/lib/utils'
import { Building2, FileText, Users, Home, BarChart3, Menu, X, Plus } from 'lucide-react'
import { useState } from 'react'
import { ThemeToggle } from '@/components/theme-toggle'

const navigation = [
  { name: 'Firmen', href: '/firmen', icon: Building2, color: 'text-cyan-500' },
  { name: 'Aufträge', href: '/auftraege', icon: FileText, color: 'text-purple-500' },
  { name: 'METIN', href: '/metin', icon: Home, color: 'text-green-500' }, // Test-Button hinzugefügt
]

export function Navigation() {
  const pathname = usePathname()
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)

  return (
    <>
      {/* Desktop Sidebar - Material 3 + iOS HIG */}
      <aside className="hidden lg:fixed lg:inset-y-0 lg:z-50 lg:flex lg:w-72 lg:flex-col">
        <div className="flex grow flex-col overflow-y-auto">
          {/* Header mit Material 3 Surface */}
          <div className="spacing-3 fintech-card border-r-0 rounded-none">
            <Link href="/firmen" className="flex items-center space-x-3 micro-bounce">
              <div className="fintech-kpi-card p-3 neon-glow-blue">
                <FileText className="h-6 w-6 text-white" />
              </div>
              <div className="flex flex-col">
                <span className="headline-small text-white font-bold">Auftragsverwaltung</span>
                <span className="label-medium text-white/70">Professional</span>
              </div>
            </Link>
            <div className="mt-4 flex justify-end">
              <ThemeToggle />
            </div>
          </div>

          {/* Primary CTA - Prominent */}
          <div className="spacing-2">
            <Link href="/auftraege/neu" className="block">
              <div className="fintech-button-primary w-full text-center micro-slide-up neon-glow-blue">
                <Plus className="inline-block mr-2 h-4 w-4" />
                Neuer Auftrag
              </div>
            </Link>
          </div>

          {/* Navigation - iOS HIG Style */}
          <nav className="flex flex-1 flex-col spacing-2">
            <ul role="list" className="flex flex-1 flex-col space-y-2">
              {navigation.map((item) => {
                const Icon = item.icon
                const isActive = pathname === item.href || 
                  (item.href !== '/' && pathname.startsWith(item.href))
                
                return (
                  <li key={item.name}>
                    <Link
                      href={item.href}
                      className={cn(
                        'flex items-center gap-x-4 px-4 py-4 title-medium rounded-2xl transition-all duration-300 micro-bounce',
                        isActive 
                          ? 'ios-card bg-gradient-to-r from-blue-500/20 to-purple-500/20 text-blue-400 neon-glow-blue' 
                          : 'text-gray-600 dark:text-gray-400 hover:bg-white/5 hover:text-white'
                      )}
                    >
                      <div className={cn(
                        'p-2 rounded-xl transition-colors',
                        isActive ? 'bg-blue-500/20' : 'bg-gray-500/10'
                      )}>
                        <Icon className={cn('h-5 w-5', isActive ? item.color : 'text-gray-500')} />
                      </div>
                      <span className="font-medium">{item.name}</span>
                    </Link>
                  </li>
                )
              })}
            </ul>

            {/* Quick Actions - Material 3 */}
            <div className="mt-auto spacing-2 space-y-2">
              <div className="text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-widest px-4">
                Schnellzugriff
              </div>
              <Link href="/firmen/neu" className="block">
                <div className="m3-button-outlined w-full text-center micro-bounce">
                  <Building2 className="inline-block mr-2 h-4 w-4" />
                  Neue Firma
                </div>
              </Link>
            </div>
          </nav>
        </div>
      </aside>

      {/* Mobile Navigation - iOS HIG Bottom Tab Bar Style */}
      <div className="lg:hidden">
        {/* Top Header */}
        <div className="sticky top-0 z-40 ios-search-bar mx-4 mt-4 mb-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="fintech-kpi-card p-2">
                <FileText className="h-5 w-5 text-blue-400" />
              </div>
              <div>
                <span className="title-medium font-bold text-gray-900 dark:text-white">Auftragsverwaltung</span>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <ThemeToggle />
              <button
                type="button"
                className="ios-button-secondary p-2 micro-bounce"
                onClick={() => setIsMobileMenuOpen(true)}
              >
                <Menu className="h-5 w-5" />
              </button>
            </div>
          </div>
        </div>

        {/* Primary CTA - Floating */}
        <div className="fixed bottom-20 right-4 z-30">
          <Link href="/auftraege/neu">
            <div className="fintech-button-primary p-4 rounded-full neon-glow-blue micro-bounce">
              <Plus className="h-6 w-6" />
            </div>
          </Link>
        </div>

          {/* Bottom Tab Navigation - iOS HIG */}
        <div className="fixed bottom-0 left-0 right-0 z-40 ios-bottom-sheet border-t-0">
          <div className="spacing-2">
            <div className="grid grid-cols-2 gap-1">
              {navigation.map((item) => {
                const Icon = item.icon
                const isActive = pathname === item.href || 
                  (item.href !== '/' && pathname.startsWith(item.href))
                
                return (
                  <Link
                    key={item.name}
                    href={item.href}
                    className={cn(
                      'flex flex-col items-center py-3 px-2 rounded-xl transition-all duration-300 micro-bounce',
                      isActive 
                        ? 'text-blue-500 bg-blue-500/10' 
                        : 'text-gray-500 dark:text-gray-400'
                    )}
                  >
                    <Icon className={cn('h-6 w-6 mb-1', isActive ? item.color : '')} />
                    <span className="label-small">{item.name}</span>
                  </Link>
                )
              })}
            </div>
          </div>
        </div>

        {/* Mobile Sidebar - Bottom Sheet Style */}
        <div className={cn(
          "relative z-50",
          isMobileMenuOpen ? "fixed inset-0" : "hidden"
        )}>
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setIsMobileMenuOpen(false)} />
          <div className="fixed inset-x-0 bottom-0 z-50 ios-bottom-sheet max-h-[80vh] overflow-y-auto">
            {/* Handle */}
            <div className="flex justify-center pt-4 pb-2">
              <div className="w-12 h-1 bg-gray-300 dark:bg-gray-600 rounded-full"></div>
            </div>
            
            {/* Header */}
            <div className="spacing-3 border-b border-gray-200 dark:border-gray-700">
              <div className="flex items-center justify-between">
                <span className="headline-small font-bold text-gray-900 dark:text-white">Navigation</span>
                <button
                  type="button"
                  className="ios-button-secondary p-2"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  <X className="h-5 w-5" />
                </button>
              </div>
            </div>
            
            {/* Navigation Items */}
            <div className="spacing-3 space-y-2">
              {navigation.map((item) => {
                const Icon = item.icon
                const isActive = pathname === item.href || 
                  (item.href !== '/' && pathname.startsWith(item.href))
                
                return (
                  <Link
                    key={item.name}
                    href={item.href}
                    className={cn(
                      'flex items-center gap-x-4 px-4 py-4 title-medium rounded-2xl transition-all duration-300',
                      isActive 
                        ? 'ios-card bg-blue-500/10 text-blue-500' 
                        : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800'
                    )}
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    <div className={cn(
                      'p-3 rounded-xl',
                      isActive ? 'bg-blue-500/20' : 'bg-gray-100 dark:bg-gray-800'
                    )}>
                      <Icon className={cn('h-6 w-6', isActive ? item.color : 'text-gray-500')} />
                    </div>
                    <span className="font-semibold">{item.name}</span>
                  </Link>
                )
              })}
              
              {/* Quick Actions in Mobile Menu */}
              <div className="pt-4 border-t border-gray-200 dark:border-gray-700 space-y-2">
                <div className="label-medium text-gray-500 dark:text-gray-400 uppercase tracking-widest px-4">
                  Schnellzugriff
                </div>
                <Link href="/firmen/neu" onClick={() => setIsMobileMenuOpen(false)}>
                  <div className="m3-button-outlined w-full text-center">
                    <Building2 className="inline-block mr-2 h-4 w-4" />
                    Neue Firma
                  </div>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}

'use client'

import { useState } from 'react'
import { useQueryClient } from '@tanstack/react-query'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Toast } from '@/components/ui/toast'
import { X, Save, User } from 'lucide-react'

interface AddProjektleiterModalProps {
  firmaId: string
  firmaName: string
  isOpen: boolean
  onClose: () => void
}

export function AddProjektleiterModal({ firmaId, firmaName, isOpen, onClose }: AddProjektleiterModalProps) {
  const queryClient = useQueryClient()
  const [isLoading, setIsLoading] = useState(false)
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null)
  const [formData, setFormData] = useState({
    vorname: '',
    nachname: '',
    telefon: '',
    email: '',
    position: '',
    notizen: ''
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      const response = await fetch('/api/projektleiter', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          vorname: formData.vorname.trim(),
          nachname: formData.nachname.trim(),
          telefon: formData.telefon.trim() || undefined,
          email: formData.email.trim() || undefined,
          position: formData.position.trim() || undefined,
          notizen: formData.notizen.trim() || undefined,
          firmaId: firmaId,
        }),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || 'Fehler beim Erstellen des Projektleiters')
      }

      const newProjektleiter = await response.json()
      
      // Invalidate queries to refresh data
      queryClient.invalidateQueries({ queryKey: ['firma', firmaId] })
      queryClient.invalidateQueries({ queryKey: ['projektleiter'] })
      
      // Success message
      setToast({ message: 'Projektleiter wurde erfolgreich hinzugefügt!', type: 'success' })
      
      // Reset form
      setFormData({
        vorname: '',
        nachname: '',
        telefon: '',
        email: '',
        position: '',
        notizen: ''
      })
      
      // Close modal after a short delay
      setTimeout(() => {
        onClose()
        setToast(null)
      }, 2000)
      
    } catch (error) {
      console.error('Fehler beim Erstellen des Projektleiters:', error)
      setToast({ 
        message: `Fehler: ${error instanceof Error ? error.message : 'Unbekannter Fehler'}`, 
        type: 'error' 
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData(prev => ({ ...prev, [name]: value }))
  }

  const handleClose = () => {
    setFormData({
      vorname: '',
      nachname: '',
      telefon: '',
      email: '',
      position: '',
      notizen: ''
    })
    setToast(null)
    onClose()
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      {/* Backdrop */}
      <div className="fixed inset-0 bg-gray-900/80" onClick={handleClose} />
      
      {/* Modal */}
      <div className="relative w-full max-w-2xl max-h-[90vh] overflow-y-auto mx-4">
        {/* Toast */}
        {toast && (
          <div className="absolute top-4 right-4 z-10">
            <Toast 
              message={toast.message} 
              type={toast.type} 
              onClose={() => setToast(null)} 
            />
          </div>
        )}
        
        <Card className="glass-card border-0 shadow-2xl">
          <CardHeader className="pb-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="p-2 rounded-lg modern-gradient">
                  <User className="h-5 w-5 text-white" />
                </div>
                <div>
                  <CardTitle className="text-xl">Neuer Projektleiter</CardTitle>
                  <CardDescription>
                    Projektleiter für {firmaName} hinzufügen
                  </CardDescription>
                </div>
              </div>
              <Button variant="ghost" size="sm" onClick={handleClose}>
                <X className="h-4 w-4" />
              </Button>
            </div>
          </CardHeader>
          
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="vorname">Vorname *</Label>
                  <Input
                    id="vorname"
                    name="vorname"
                    value={formData.vorname}
                    onChange={handleChange}
                    placeholder="z.B. Max"
                    className="rounded-xl border-2"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="nachname">Nachname *</Label>
                  <Input
                    id="nachname"
                    name="nachname"
                    value={formData.nachname}
                    onChange={handleChange}
                    placeholder="z.B. Mustermann"
                    className="rounded-xl border-2"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="position">Position</Label>
                <Input
                  id="position"
                  name="position"
                  value={formData.position}
                  onChange={handleChange}
                  placeholder="z.B. Senior Projektmanager"
                  className="rounded-xl border-2"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="telefon">Telefon</Label>
                  <Input
                    id="telefon"
                    name="telefon"
                    value={formData.telefon}
                    onChange={handleChange}
                    placeholder="+49 30 12345678"
                    className="rounded-xl border-2"
                    type="tel"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">E-Mail</Label>
                  <Input
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="max.mustermann@firma.de"
                    className="rounded-xl border-2"
                    type="email"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="notizen">Notizen</Label>
                <Textarea
                  id="notizen"
                  name="notizen"
                  value={formData.notizen}
                  onChange={handleChange}
                  placeholder="Zusätzliche Informationen über den Projektleiter..."
                  className="rounded-xl border-2"
                  rows={3}
                />
              </div>

              {/* Aktionen */}
              <div className="flex justify-end space-x-4 pt-4">
                <Button 
                  variant="outline" 
                  type="button" 
                  onClick={handleClose}
                  className="rounded-xl"
                  disabled={isLoading}
                >
                  Abbrechen
                </Button>
                <Button 
                  type="submit" 
                  disabled={isLoading || !formData.vorname.trim() || !formData.nachname.trim()}
                  className="modern-gradient rounded-xl"
                >
                  {isLoading ? (
                    <>
                      <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
                      Erstelle...
                    </>
                  ) : (
                    <>
                      <Save className="mr-2 h-4 w-4" />
                      Projektleiter hinzufügen
                    </>
                  )}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}


'use client'

import { useQuery } from '@tanstack/react-query'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Building2, FileText, Users, TrendingUp } from 'lucide-react'

export function DashboardStats() {
  const { data: firmen } = useQuery({
    queryKey: ['firmen'],
    queryFn: async () => {
      const response = await fetch('/api/firmen')
      if (!response.ok) throw new Error('Fehler beim Laden')
      return response.json()
    }
  })

  const { data: auftraege } = useQuery({
    queryKey: ['auftraege'],
    queryFn: async () => {
      const response = await fetch('/api/auftraege')
      if (!response.ok) throw new Error('Fehler beim Laden')
      return response.json()
    }
  })

  const stats = [
    {
      title: 'Firmen',
      value: firmen?.length || 0,
      icon: Building2,
      description: 'Registrierte Firmen'
    },
    {
      title: 'Aufträge',
      value: auftraege?.length || 0,
      icon: FileText,
      description: 'Gesamte Aufträge'
    },
    {
      title: 'Aktive Aufträge',
      value: auftraege?.filter((a: any) => a.status === 'IN_BEARBEITUNG').length || 0,
      icon: TrendingUp,
      description: 'In Bearbeitung'
    },
    {
      title: 'Projektleiter',
      value: firmen?.reduce((sum: number, firma: any) => sum + (firma._count?.projektleiter || 0), 0) || 0,
      icon: Users,
      description: 'Registrierte Projektleiter'
    }
  ]

  return (
    <div className="spacing-4 lg:spacing-6">
      <div className="grid gap-4 sm:gap-6 grid-cols-2 lg:grid-cols-4">
        {stats.map((stat, index) => {
          const Icon = stat.icon
          const neonEffects = [
            'neon-glow-blue',
            'neon-glow-cyan', 
            'neon-glow-purple',
            'neon-glow-blue'
          ]
          const iconColors = [
            'text-blue-400',
            'text-cyan-400',
            'text-purple-400', 
            'text-orange-400'
          ]
          
          return (
            <div key={index} className={`fintech-kpi-card spacing-3 micro-slide-up ${neonEffects[index]}`}>
              <div className="flex flex-col space-y-4">
                {/* Icon mit Neon-Effekt */}
                <div className="flex items-center justify-between">
                  <div className="fintech-kpi-card p-3 bg-white/5">
                    <Icon className={`h-8 w-8 ${iconColors[index]}`} />
                  </div>
                  <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse"></div>
                </div>
                
                {/* Wert - Fintech Typography */}
                <div>
                  <div className="display-small font-bold text-white mb-1 font-mono">
                    {stat.value.toLocaleString()}
                  </div>
                  <p className="label-medium text-gray-400 uppercase tracking-widest">
                    {stat.title}
                  </p>
                  <p className="body-small text-gray-500 mt-1">
                    {stat.description}
                  </p>
                </div>
                
                {/* Trend Indicator */}
                <div className="flex items-center space-x-2">
                  <div className="w-full bg-white/10 rounded-full h-1">
                    <div className={`h-1 rounded-full bg-gradient-to-r ${
                      index === 0 ? 'from-blue-400 to-cyan-400 w-3/4' :
                      index === 1 ? 'from-cyan-400 to-blue-400 w-4/5' :
                      index === 2 ? 'from-purple-400 to-pink-400 w-2/3' :
                      'from-orange-400 to-red-400 w-5/6'
                    }`}></div>
                  </div>
                  <span className="label-small text-cyan-400">+12%</span>
                </div>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}

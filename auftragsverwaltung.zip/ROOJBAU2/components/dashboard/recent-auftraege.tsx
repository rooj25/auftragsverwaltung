'use client'

import { useQuery } from '@tanstack/react-query'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { getStatusColor, getStatusText, formatDate } from '@/lib/utils'
import { Eye } from 'lucide-react'
import Link from 'next/link'
import { Building2, Clock } from 'lucide-react'

export function RecentAuftraege() {
  const { data: auftraege, isLoading } = useQuery({
    queryKey: ['auftraege'],
    queryFn: async () => {
      const response = await fetch('/api/auftraege')
      if (!response.ok) throw new Error('Fehler beim Laden')
      return response.json()
    }
  })

  if (isLoading) {
    return (
      <div className="space-y-3">
        {[...Array(3)].map((_, i) => (
          <div key={i} className="animate-pulse">
            <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
            <div className="h-3 bg-gray-200 rounded w-1/2"></div>
          </div>
        ))}
      </div>
    )
  }

  const recentAuftraege = auftraege?.slice(0, 5) || []

  if (recentAuftraege.length === 0) {
    return (
      <div className="text-center py-6">
        <p className="text-muted-foreground">Noch keine Aufträge vorhanden</p>
        <Button className="mt-2" asChild>
          <Link href="/auftraege/neu">Ersten Auftrag erstellen</Link>
        </Button>
      </div>
    )
  }

  return (
    <div className="space-y-3 sm:space-y-4">
      {recentAuftraege.map((auftrag: any) => (
        <div key={auftrag.id} className="modern-auftrag-card p-4 hover:shadow-lg transition-shadow">
          {/* Mobile: Wie im Screenshot */}
          <div className="block sm:hidden">
            <div className="flex flex-col space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-lg text-gray-900 dark:text-white">{auftrag.auftragsnummer}</h4>
                <Badge className={getStatusColor(auftrag.status)}>
                  {getStatusText(auftrag.status)}
                </Badge>
              </div>
              <p className="text-gray-700 dark:text-gray-300 text-sm">{auftrag.titel}</p>
              <div className="flex items-center text-sm text-gray-600 dark:text-gray-400">
                <Building2 className="mr-2 h-4 w-4" />
                <span>{auftrag.firma?.name}</span>
              </div>
              {auftrag.geplantesEnddatum && (
                <div className="flex items-center text-sm text-gray-600 dark:text-gray-400">
                  <Clock className="mr-2 h-4 w-4" />
                  <span>Fällig: {formatDate(auftrag.geplantesEnddatum)}</span>
                </div>
              )}
              <Button asChild className="modern-button-primary w-full mt-3">
                <Link href={`/auftraege/${auftrag.id}`}>
                  <Eye className="mr-2 h-4 w-4" />
                  Details
                </Link>
              </Button>
            </div>
          </div>

          {/* Desktop: Kompakte Ansicht */}
          <div className="hidden sm:flex items-center justify-between p-3">
            <div className="flex-1 min-w-0">
              <div className="flex items-center space-x-2 mb-1">
                <h4 className="font-medium truncate text-gray-900 dark:text-white">{auftrag.titel}</h4>
                <Badge className={getStatusColor(auftrag.status)}>
                  {getStatusText(auftrag.status)}
                </Badge>
              </div>
              <div className="text-sm text-gray-600 dark:text-gray-400">
                <span>{auftrag.firma?.name}</span>
                {auftrag.geplantesEnddatum && (
                  <span> • Fällig: {formatDate(auftrag.geplantesEnddatum)}</span>
                )}
              </div>
            </div>
            <Button variant="ghost" size="sm" asChild className="text-gray-600 dark:text-gray-400 hover:text-primary dark:hover:text-primary">
              <Link href={`/auftraege/${auftrag.id}`}>
                <Eye className="h-5 w-5" />
              </Link>
            </Button>
          </div>
        </div>
      ))}
      
      {auftraege && auftraege.length > 5 && (
        <div className="text-center pt-2">
          <Button variant="outline" asChild>
            <Link href="/auftraege">Alle Aufträge anzeigen</Link>
          </Button>
        </div>
      )}
    </div>
  )
}

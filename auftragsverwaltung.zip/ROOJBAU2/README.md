# 🏢 Auftragsverwaltung - Professionelle Lösung für Subunternehmen

Eine moderne, benutzerfreundliche Web-Anwendung zur effizienten Verwaltung von Aufträgen, Firmen und Projektleitern für Ihr Subunternehmen.

![Dashboard](https://img.shields.io/badge/Status-Ready%20to%20Use-green)
![Version](https://img.shields.io/badge/Version-1.0.0-blue)
![Tech Stack](https://img.shields.io/badge/Tech-Next.js%2014%20%7C%20TypeScript%20%7C%20Prisma-orange)

## 🚀 Funktionen

### 📊 **Dashboard**
- Übersichtliche Statistiken zu Firmen, Aufträgen und Projektleitern
- Aktuelle Aufträge mit Status-Anzeige
- Schnellzugriff auf wichtige Funktionen

### 🏢 **Firmenverwaltung**
- **Firmen hinzufügen**: Name, Adresse, Kontaktdaten, Notizen
- **Projektleiter verwalten**: Name, Nachname, Telefon, E-Mail, Position, Notizen
- **Firmendetails anzeigen**: Vollständige Informationen und zugeordnete Aufträge
- **Bearbeitung**: Alle Firmen- und Projektleiter-Daten aktualisierbar
- **Suchfunktion**: Schnelles Finden von Firmen

### 📋 **Auftragsverwaltung**
- **Aufträge erstellen**: Automatische Auftragsnummer, Titel, Beschreibung
- **Status-Management**: Neu → In Bearbeitung → Wartend → Abgeschlossen → Storniert
- **Prioritäten**: Niedrig, Normal, Hoch, Kritisch
- **Zeitplanung**: Start- und Enddatum, geschätzter vs. tatsächlicher Aufwand
- **Kostenerfassung**: Budgetplanung und -verfolgung
- **Status-Verlauf**: Komplette Historie aller Änderungen

### 🎨 **Benutzeroberfläche**
- **Responsive Design**: Funktioniert auf Desktop, Tablet und Mobile
- **Moderne UI**: Professionelles Design mit Tailwind CSS
- **Intuitive Navigation**: Einfache Bedienung für alle Benutzer
- **Schnelle Performance**: Optimiert für beste Benutzererfahrung

## 🛠️ Technologie-Stack

- **Frontend**: Next.js 14, React 18, TypeScript
- **Styling**: Tailwind CSS, Radix UI Komponenten
- **Backend**: Next.js API Routes
- **Datenbank**: SQLite (Prisma ORM)
- **State Management**: TanStack Query (React Query)
- **Formulare**: React Hook Form mit Zod Validierung

## 📦 Installation

### Voraussetzungen
- Node.js 18.0 oder höher
- npm oder yarn

### Schritt-für-Schritt Installation

1. **Repository klonen oder Dateien herunterladen**
   ```bash
   # Falls Git verwendet wird:
   git clone <repository-url>
   cd auftragsverwaltung
   ```

2. **Abhängigkeiten installieren**
   ```bash
   npm install
   # oder
   yarn install
   ```

3. **Umgebungsvariablen einrichten**
   ```bash
   # .env Datei ist bereits erstellt
   # Standardkonfiguration sollte funktionieren
   ```

4. **Datenbank einrichten**
   ```bash
   # Prisma Client generieren
   npm run db:generate
   
   # Datenbank-Schema anwenden
   npm run db:push
   
   # Beispieldaten einfügen (optional)
   npm run db:seed
   ```

5. **Entwicklungsserver starten**
   ```bash
   npm run dev
   ```

6. **Anwendung öffnen**
   - Öffnen Sie [http://localhost:3000](http://localhost:3000) in Ihrem Browser
   - Die Anwendung ist sofort einsatzbereit!

## 🚀 Schnellstart

Nach der Installation haben Sie bereits Beispieldaten:

### 📊 **Beispiel-Firmen:**
- **TechCorp GmbH** mit Projektleiter Max Mustermann
- **StartUp Solutions** mit Projektleiterin Anna Schmidt

### 📋 **Beispiel-Aufträge:**
- Website Redesign (In Bearbeitung)
- Mobile App Entwicklung (Neu)

### 🎯 **Erste Schritte:**
1. **Dashboard erkunden** - Verschaffen Sie sich einen Überblick
2. **Neue Firma hinzufügen** - Klicken Sie auf "Neue Firma"
3. **Projektleiter zuordnen** - In den Firmendetails
4. **Ersten Auftrag erstellen** - Über "Neuer Auftrag"

## 📁 Projektstruktur

```
auftragsverwaltung/
├── app/                    # Next.js App Router
│   ├── api/               # Backend API Routen
│   ├── firmen/            # Firmen-Verwaltungsseiten
│   ├── auftraege/         # Auftrags-Verwaltungsseiten
│   └── globals.css        # Globale Styles
├── components/            # React Komponenten
│   ├── ui/               # Basis UI-Komponenten
│   ├── dashboard/        # Dashboard-spezifische Komponenten
│   └── navigation.tsx    # Hauptnavigation
├── lib/                  # Utility-Funktionen
│   ├── prisma.ts        # Datenbankverbindung
│   └── utils.ts         # Hilfsfunktionen
├── prisma/              # Datenbank-Schema und Seed
│   ├── schema.prisma    # Datenbankmodell
│   └── seed.ts          # Beispieldaten
└── README.md            # Diese Datei
```

## 🎨 Features im Detail

### Firmenverwaltung
- ✅ Firmen mit vollständigen Kontaktdaten anlegen
- ✅ Mehrere Projektleiter pro Firma verwalten
- ✅ Suchfunktion für schnelles Auffinden
- ✅ Übersichtliche Karten-Darstellung
- ✅ Statistiken zu Projektleitern und Aufträgen

### Auftragsverwaltung
- ✅ Automatische Auftragsnummerierung (AUF-YYYY-XXX)
- ✅ Umfassende Auftragsdetails
- ✅ Status-Tracking mit Verlauf
- ✅ Prioritäten-Management
- ✅ Zeit- und Kostenerfassung
- ✅ Zuordnung zu Firmen und Projektleitern

### Dashboard
- ✅ Echtzeit-Statistiken
- ✅ Aktuelle Aufträge-Übersicht
- ✅ Schnellzugriff auf häufige Aktionen
- ✅ Wichtige Hinweise und Tipps

## 🔧 Verfügbare Scripts

```bash
# Entwicklung
npm run dev          # Entwicklungsserver starten
npm run build        # Production Build erstellen
npm run start        # Production Server starten
npm run lint         # Code-Qualität prüfen

# Datenbank
npm run db:generate  # Prisma Client generieren
npm run db:push      # Schema in Datenbank übertragen
npm run db:studio    # Prisma Studio öffnen (Datenbank-GUI)
npm run db:seed      # Beispieldaten einfügen
```

## 🔒 Sicherheit

- ✅ TypeScript für Type Safety
- ✅ Zod-Validierung für alle API-Eingaben
- ✅ Sichere Datenbankoperationen mit Prisma
- ✅ Input-Sanitization und Validierung

## 📱 Responsive Design

Die Anwendung ist vollständig responsive und funktioniert optimal auf:
- 🖥️ **Desktop** (1920px+)
- 💻 **Laptop** (1024px - 1919px)
- 📱 **Tablet** (768px - 1023px)
- 📱 **Mobile** (320px - 767px)

## 🚀 Deployment

### Lokaler Betrieb
```bash
npm run build
npm run start
```

### Vercel (Empfohlen)
1. Repository zu Vercel verbinden
2. Umgebungsvariablen konfigurieren
3. Automatisches Deployment

### Andere Plattformen
- Docker-Support möglich
- Kompatibel mit allen Node.js-Hosting-Anbietern

## 📊 Performance

- ⚡ **Schnelle Ladezeiten** durch Next.js Optimierungen
- 🔄 **Effiziente Datenabfragen** mit React Query Caching
- 📱 **Mobile-optimiert** für beste Performance auf allen Geräten
- 🎯 **SEO-freundlich** durch Server-Side Rendering

## 🆘 Support & Troubleshooting

### Häufige Probleme

**Problem: Datenbank-Fehler beim ersten Start**
```bash
# Lösung:
npm run db:generate
npm run db:push
```

**Problem: Port 3000 bereits belegt**
```bash
# Anderen Port verwenden:
npm run dev -- -p 3001
```

**Problem: Abhängigkeiten-Konflikte**
```bash
# Node modules neu installieren:
rm -rf node_modules package-lock.json
npm install
```

## 🔮 Roadmap

### Geplante Features
- [ ] **Export/Import**: CSV-Export für Berichte
- [ ] **Benachrichtigungen**: E-Mail-Alerts für Deadlines
- [ ] **Benutzerrollen**: Multi-User-Support mit Rechten
- [ ] **Zeiterfassung**: Integrierte Zeitstempelung
- [ ] **Dokumentenanhänge**: Dateien zu Aufträgen hinzufügen
- [ ] **API-Dokumentation**: Swagger/OpenAPI Integration

## 📄 Lizenz

Dieses Projekt ist für den internen Gebrauch in Ihrem Subunternehmen entwickelt.

---

**🎉 Viel Erfolg mit Ihrer neuen Auftragsverwaltung!**

Bei Fragen oder Problemen können Sie die Dokumentation konsultieren oder die Anwendung entsprechend Ihren Bedürfnissen anpassen.


import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatDate(date: Date | string | null | undefined): string {
  if (!date) return 'Nicht gesetzt'
  
  const d = typeof date === 'string' ? new Date(date) : date
  return d.toLocaleDateString('de-DE', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  })
}

export function formatCurrency(amount: number | null | undefined): string {
  if (!amount) return '0,00 €'
  
  return new Intl.NumberFormat('de-DE', {
    style: 'currency',
    currency: 'EUR'
  }).format(amount)
}

export function getStatusColor(status: string): string {
  switch (status) {
    case 'NEU':
      return 'bg-blue-100 dark:bg-blue-900/30 text-blue-800 dark:text-blue-200'
    case 'IN_BEARBEITUNG':
      return 'bg-yellow-100 dark:bg-yellow-900/30 text-yellow-800 dark:text-yellow-200'
    case 'WARTEND':
      return 'bg-orange-100 dark:bg-orange-900/30 text-orange-800 dark:text-orange-200'
    case 'ABGESCHLOSSEN':
      return 'bg-gray-100 dark:bg-gray-900/30 text-gray-800 dark:text-gray-200'
    case 'STORNIERT':
      return 'bg-red-100 dark:bg-red-900/30 text-red-800 dark:text-red-200'
    default:
      return 'bg-gray-100 dark:bg-gray-900/30 text-gray-800 dark:text-gray-200'
  }
}

export function getPriorityColor(priority: string): string {
  switch (priority) {
    case 'NIEDRIG':
      return 'bg-gray-100 dark:bg-gray-900/30 text-gray-800 dark:text-gray-200'
    case 'NORMAL':
      return 'bg-blue-100 dark:bg-blue-900/30 text-blue-800 dark:text-blue-200'
    case 'HOCH':
      return 'bg-orange-100 dark:bg-orange-900/30 text-orange-800 dark:text-orange-200'
    case 'KRITISCH':
      return 'bg-red-100 dark:bg-red-900/30 text-red-800 dark:text-red-200'
    default:
      return 'bg-gray-100 dark:bg-gray-900/30 text-gray-800 dark:text-gray-200'
  }
}

export function getStatusText(status: string): string {
  const statusMap: Record<string, string> = {
    'NEU': 'Neu',
    'IN_BEARBEITUNG': 'In Bearbeitung',
    'WARTEND': 'Wartend',
    'ABGESCHLOSSEN': 'Abgeschlossen',
    'STORNIERT': 'Storniert'
  }
  return statusMap[status] || status
}

export function getPriorityText(priority: string): string {
  const priorityMap: Record<string, string> = {
    'NIEDRIG': 'Niedrig',
    'NORMAL': 'Normal',
    'HOCH': 'Hoch',
    'KRITISCH': 'Kritisch'
  }
  return priorityMap[priority] || priority
}

'use client'

import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Building2, Users, FileText, Plus, Search } from 'lucide-react'
import Link from 'next/link'

interface Firma {
  id: string
  name: string
  adresse?: string
  telefon?: string
  email?: string
  website?: string
  notizen?: string
  _count: {
    projektleiter: number
    auftraege: number
  }
}

export default function FirmenPage() {
  const [searchTerm, setSearchTerm] = useState('')

  const { data: firmen, isLoading, error } = useQuery({
    queryKey: ['firmen'],
    queryFn: async () => {
      const response = await fetch('/api/firmen')
      if (!response.ok) {
        throw new Error('Fehler beim Laden der Firmen')
      }
      return response.json() as Promise<Firma[]>
    }
  })

  const filteredFirmen = firmen?.filter(firma =>
    firma.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    firma.adresse?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    firma.email?.toLowerCase().includes(searchTerm.toLowerCase())
  ) || []

  if (isLoading) {
    return (
      <div className="min-h-screen">
        <div className="spacing-4 lg:spacing-6">
          <div className="text-center space-y-4">
            <h1 className="headline-large font-bold text-gray-900 dark:text-white">Firmen</h1>
            <div className="fintech-kpi-card spacing-4 max-w-md mx-auto">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-cyan-400 mx-auto mb-4"></div>
              <p className="body-medium text-gray-400">Firmen werden geladen...</p>
            </div>
          </div>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="min-h-screen">
        <div className="spacing-4 lg:spacing-6">
          <div className="text-center space-y-4">
            <h1 className="headline-large font-bold text-gray-900 dark:text-white">Firmen</h1>
            <div className="fintech-card spacing-4 max-w-md mx-auto">
              <p className="body-medium text-red-400">Fehler beim Laden der Firmen. Bitte versuchen Sie es erneut.</p>
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen">
      {/* Hero Section - Material 3 */}
      <div className="spacing-4 lg:spacing-6">
        <div className="text-center lg:text-left space-y-4">
          <div className="space-y-2">
            <h1 className="display-medium lg:display-large font-bold bg-gradient-to-r from-cyan-400 via-blue-400 to-purple-400 bg-clip-text text-transparent">
              Firmen
            </h1>
            <p className="body-large text-gray-600 dark:text-gray-400 max-w-2xl">
              Verwalten Sie Ihre Geschäftspartner und deren Projektleiter effizient
            </p>
          </div>
          
          {/* Primary CTA */}
          <div className="flex justify-center lg:justify-start">
            <Link href="/firmen/neu">
              <div className="fintech-button-primary micro-slide-up neon-glow-cyan">
                <Plus className="mr-2 h-4 w-4" />
                Neue Firma
              </div>
            </Link>
          </div>
        </div>
      </div>

      {/* Sticky Search Bar - iOS Style */}
      <div className="sticky top-0 z-30 spacing-2">
        <div className="ios-search-bar mx-4 lg:mx-6">
          <div className="flex items-center space-x-3">
            <Search className="h-5 w-5 text-gray-400 dark:text-gray-500" />
            <input
              placeholder="Firmen durchsuchen..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="flex-1 bg-transparent border-none outline-none text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400"
            />
            <div className="ios-button-secondary px-3 py-1 text-xs">
              {filteredFirmen.length} / {firmen?.length || 0}
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="spacing-4 lg:spacing-6">
        {filteredFirmen.length === 0 ? (
          <div className="text-center">
            <div className="fintech-card spacing-4 max-w-md mx-auto">
              <div className="fintech-kpi-card p-4 mx-auto w-fit mb-4 neon-glow-cyan">
                <Building2 className="h-12 w-12 text-cyan-400" />
              </div>
              <h3 className="title-large font-bold text-white mb-2">Keine Firmen gefunden</h3>
              <p className="body-medium text-gray-400 mb-6">
                {searchTerm ? 'Keine Firmen entsprechen Ihrer Suche.' : 'Sie haben noch keine Firmen hinzugefügt.'}
              </p>
              <Link href="/firmen/neu">
                <div className="fintech-button-primary micro-bounce">
                  <Plus className="mr-2 h-4 w-4" />
                  Erste Firma hinzufügen
                </div>
              </Link>
            </div>
          </div>
        ) : (
          <>
            {/* Mobile: iOS Cards */}
            <div className="mobile-only space-y-4">
              {filteredFirmen.map((firma) => (
                <div key={firma.id} className="ios-card spacing-3 micro-slide-up">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1 min-w-0">
                      <h3 className="title-large font-bold text-gray-900 dark:text-white truncate">{firma.name}</h3>
                      {firma.adresse && (
                        <p className="body-small text-gray-600 dark:text-gray-400 truncate mt-1">{firma.adresse}</p>
                      )}
                    </div>
                  </div>
                  
                  {(firma.telefon || firma.email) && (
                    <div className="space-y-2 mb-4">
                      {firma.telefon && (
                        <p className="body-small text-gray-600 dark:text-gray-400">📞 {firma.telefon}</p>
                      )}
                      {firma.email && (
                        <p className="body-small text-gray-600 dark:text-gray-400">✉️ {firma.email}</p>
                      )}
                    </div>
                  )}
                  
                  <div className="flex items-center justify-between pt-3 border-t border-gray-200 dark:border-gray-700">
                    <div className="flex space-x-4">
                      <div className="flex items-center space-x-1">
                        <div className="fintech-kpi-card p-1">
                          <Users className="h-3 w-3 text-cyan-400" />
                        </div>
                        <span className="label-small text-gray-700 dark:text-gray-300">{firma._count.projektleiter}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <div className="fintech-kpi-card p-1">
                          <FileText className="h-3 w-3 text-purple-400" />
                        </div>
                        <span className="label-small text-gray-700 dark:text-gray-300">{firma._count.auftraege}</span>
                      </div>
                    </div>
                  <div className="grid grid-cols-2 gap-2">
                    <Link href={`/firmen/${firma.id}`}>
                      <div className="ios-button-secondary text-center py-3 text-xs micro-bounce">
                        Details
                      </div>
                    </Link>
                    <Link href={`/firmen/${firma.id}/bearbeiten`}>
                      <div className="ios-button-secondary text-center py-3 text-xs micro-bounce">
                        Bearbeiten
                      </div>
                    </Link>
                  </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Desktop: Material 3 Table */}
            <div className="desktop-only">
              <div className="m3-card-elevated spacing-4">
                {/* Header */}
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center space-x-3">
                    <div className="fintech-kpi-card p-3 neon-glow-cyan">
                      <Building2 className="h-6 w-6 text-cyan-400" />
                    </div>
                    <div>
                      <h2 className="headline-small font-bold text-gray-900 dark:text-white">Alle Firmen</h2>
                      <p className="body-medium text-gray-600 dark:text-gray-400">{filteredFirmen.length} Geschäftspartner</p>
                    </div>
                  </div>
                </div>

                {/* Table Header */}
                <div className="grid grid-cols-12 gap-4 pb-3 border-b border-gray-200 dark:border-gray-700">
                  <div className="col-span-3">
                    <span className="label-medium text-gray-600 dark:text-gray-400 uppercase tracking-widest">Firma</span>
                  </div>
                  <div className="col-span-3">
                    <span className="label-medium text-gray-600 dark:text-gray-400 uppercase tracking-widest">Kontakt</span>
                  </div>
                  <div className="col-span-2">
                    <span className="label-medium text-gray-600 dark:text-gray-400 uppercase tracking-widest">Projektleiter</span>
                  </div>
                  <div className="col-span-2">
                    <span className="label-medium text-gray-600 dark:text-gray-400 uppercase tracking-widest">Aufträge</span>
                  </div>
                  <div className="col-span-2">
                    <span className="label-medium text-gray-600 dark:text-gray-400 uppercase tracking-widest">Aktionen</span>
                  </div>
                </div>

                {/* Table Rows */}
                <div className="space-y-2 mt-4">
                  {filteredFirmen.map((firma) => (
                    <div key={firma.id} className="grid grid-cols-12 gap-4 items-center py-4 px-3 rounded-xl hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-all duration-300 micro-bounce">
                      <div className="col-span-3">
                        <div className="title-medium font-bold text-gray-900 dark:text-white">{firma.name}</div>
                        {firma.adresse && (
                          <div className="body-small text-gray-600 dark:text-gray-400 truncate mt-1">{firma.adresse}</div>
                        )}
                      </div>
                      <div className="col-span-3 space-y-1">
                        {firma.telefon && (
                          <div className="body-small text-gray-600 dark:text-gray-400">📞 {firma.telefon}</div>
                        )}
                        {firma.email && (
                          <div className="body-small text-gray-600 dark:text-gray-400 truncate">✉️ {firma.email}</div>
                        )}
                      </div>
                      <div className="col-span-2">
                        <div className="flex items-center space-x-2">
                          <div className="fintech-kpi-card p-2">
                            <Users className="h-4 w-4 text-cyan-400" />
                          </div>
                          <span className="title-medium font-bold text-gray-900 dark:text-white">{firma._count.projektleiter}</span>
                        </div>
                      </div>
                      <div className="col-span-2">
                        <div className="flex items-center space-x-2">
                          <div className="fintech-kpi-card p-2">
                            <FileText className="h-4 w-4 text-purple-400" />
                          </div>
                          <span className="title-medium font-bold text-gray-900 dark:text-white">{firma._count.auftraege}</span>
                        </div>
                      </div>
                      <div className="col-span-2">
                        <div className="flex space-x-2">
                          <Link href={`/firmen/${firma.id}`}>
                            <div className="ios-button-secondary px-3 py-2 text-xs micro-bounce">
                              Details
                            </div>
                          </Link>
                          <Link href={`/firmen/${firma.id}/bearbeiten`}>
                            <div className="m3-button-outlined px-3 py-2 text-xs micro-bounce">
                              Bearbeiten
                            </div>
                          </Link>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  )
}

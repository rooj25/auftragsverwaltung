'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { ArrowLeft, Save, Users } from 'lucide-react'
import Link from 'next/link'

export default function NeueFirmaPage() {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [formData, setFormData] = useState({
    name: '',
    adresse: '',
    telefon: '',
    email: '',
    website: '',
    notizen: '',
    // Projektleiter Felder
    projektleiterVorname: '',
    projektleiterNachname: '',
    projektleiterTelefon: '',
    projektleiterEmail: '',
    projektleiterPosition: '',
    projektleiterNotizen: ''
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      // Erst die Firma erstellen
      const firmaData = {
        name: formData.name,
        adresse: formData.adresse,
        telefon: formData.telefon,
        email: formData.email,
        website: formData.website,
        notizen: formData.notizen
      }

      const firmaResponse = await fetch('/api/firmen', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(firmaData),
      })

      if (!firmaResponse.ok) {
        const error = await firmaResponse.json()
        throw new Error(error.error || 'Fehler beim Erstellen der Firma')
      }

      const firma = await firmaResponse.json()

      // Wenn Projektleiter-Daten vorhanden sind, diese auch erstellen
      if (formData.projektleiterVorname.trim() && formData.projektleiterNachname.trim()) {
        const projektleiterData = {
          vorname: formData.projektleiterVorname.trim(),
          nachname: formData.projektleiterNachname.trim(),
          telefon: formData.projektleiterTelefon.trim() || undefined,
          email: formData.projektleiterEmail.trim() || undefined,
          position: formData.projektleiterPosition.trim() || undefined,
          notizen: formData.projektleiterNotizen.trim() || undefined,
          firmaId: firma.id
        }

        const projektleiterResponse = await fetch('/api/projektleiter', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(projektleiterData),
        })

        if (!projektleiterResponse.ok) {
          console.warn('Projektleiter konnte nicht erstellt werden, aber Firma wurde erfolgreich erstellt')
        }
      }

      router.push(`/firmen/${firma.id}`)
    } catch (error) {
      console.error('Fehler beim Erstellen der Firma:', error)
      alert('Fehler beim Erstellen der Firma. Bitte versuchen Sie es erneut.')
    } finally {
      setIsLoading(false)
    }
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData(prev => ({ ...prev, [name]: value }))
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gradient-to-br dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 transition-colors duration-300">
      {/* Header */}
      <div className="bg-white dark:bg-gray-900/95 dark:backdrop-blur-md border-b border-gray-200 dark:border-gray-700/50 px-6 py-6">
        <div className="flex items-center space-x-4">
          <Button variant="ghost" size="sm" asChild className="text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800">
            <Link href="/firmen">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Zurück zu Firmen
            </Link>
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Neue Firma</h1>
            <p className="text-gray-600 dark:text-gray-400 mt-1">Fügen Sie eine neue Firma zu Ihrem System hinzu</p>
          </div>
        </div>
      </div>

      {/* Formular */}
      <div className="px-6 py-6">
        <div className="max-w-2xl mx-auto">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Firmeninformationen */}
            <Card className="dark-card-modern">
              <CardHeader>
                <CardTitle className="text-xl text-gray-900 dark:text-white">Firmeninformationen</CardTitle>
                <CardDescription className="text-gray-600 dark:text-gray-400">
                  Geben Sie die grundlegenden Informationen der Firma ein
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="name" className="text-gray-700 dark:text-gray-300">Firmenname *</Label>
                  <Input
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    placeholder="z.B. TechCorp GmbH"
                    className="rounded-xl border-2 bg-white dark:bg-gray-800 dark:border-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-primary focus:border-primary"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="adresse" className="text-gray-700 dark:text-gray-300">Adresse</Label>
                  <Textarea
                    id="adresse"
                    name="adresse"
                    value={formData.adresse}
                    onChange={handleChange}
                    placeholder="Straße, PLZ Stadt"
                    className="rounded-xl border-2 bg-white dark:bg-gray-800 dark:border-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-primary focus:border-primary"
                    rows={2}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="telefon" className="text-gray-700 dark:text-gray-300">Telefon</Label>
                    <Input
                      id="telefon"
                      name="telefon"
                      value={formData.telefon}
                      onChange={handleChange}
                      placeholder="+49 30 12345678"
                      className="rounded-xl border-2 bg-white dark:bg-gray-800 dark:border-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-primary focus:border-primary"
                      type="tel"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email" className="text-gray-700 dark:text-gray-300">E-Mail</Label>
                    <Input
                      id="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      placeholder="info@firma.de"
                      className="rounded-xl border-2 bg-white dark:bg-gray-800 dark:border-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-primary focus:border-primary"
                      type="email"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="website" className="text-gray-700 dark:text-gray-300">Website</Label>
                  <Input
                    id="website"
                    name="website"
                    value={formData.website}
                    onChange={handleChange}
                    placeholder="https://www.firma.de"
                    className="rounded-xl border-2 bg-white dark:bg-gray-800 dark:border-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-primary focus:border-primary"
                    type="url"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="notizen" className="text-gray-700 dark:text-gray-300">Notizen</Label>
                  <Textarea
                    id="notizen"
                    name="notizen"
                    value={formData.notizen}
                    onChange={handleChange}
                    placeholder="Zusätzliche Informationen über die Firma..."
                    className="rounded-xl border-2 bg-white dark:bg-gray-800 dark:border-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-primary focus:border-primary"
                    rows={4}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Projektleiter */}
            <Card className="dark-card-modern">
              <CardHeader>
                <CardTitle className="flex items-center text-xl text-gray-900 dark:text-white">
                  <div className="p-2 bg-primary rounded-lg mr-3">
                    <Users className="h-5 w-5 text-white" />
                  </div>
                  Projektleiter (optional)
                </CardTitle>
                <CardDescription className="text-gray-600 dark:text-gray-400">
                  Fügen Sie direkt einen Projektleiter für diese Firma hinzu
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="projektleiterVorname" className="text-gray-700 dark:text-gray-300">Vorname</Label>
                    <Input
                      id="projektleiterVorname"
                      name="projektleiterVorname"
                      value={formData.projektleiterVorname}
                      onChange={handleChange}
                      placeholder="z.B. Max"
                      className="rounded-xl border-2 bg-white dark:bg-gray-800 dark:border-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-primary focus:border-primary"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="projektleiterNachname" className="text-gray-700 dark:text-gray-300">Nachname</Label>
                    <Input
                      id="projektleiterNachname"
                      name="projektleiterNachname"
                      value={formData.projektleiterNachname}
                      onChange={handleChange}
                      placeholder="z.B. Mustermann"
                      className="rounded-xl border-2 bg-white dark:bg-gray-800 dark:border-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-primary focus:border-primary"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="projektleiterPosition" className="text-gray-700 dark:text-gray-300">Position</Label>
                  <Input
                    id="projektleiterPosition"
                    name="projektleiterPosition"
                    value={formData.projektleiterPosition}
                    onChange={handleChange}
                    placeholder="z.B. Projektmanager"
                    className="rounded-xl border-2 bg-white dark:bg-gray-800 dark:border-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-primary focus:border-primary"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="projektleiterTelefon" className="text-gray-700 dark:text-gray-300">Telefon</Label>
                    <Input
                      id="projektleiterTelefon"
                      name="projektleiterTelefon"
                      value={formData.projektleiterTelefon}
                      onChange={handleChange}
                      placeholder="+49 30 12345678"
                      className="rounded-xl border-2 bg-white dark:bg-gray-800 dark:border-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-primary focus:border-primary"
                      type="tel"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="projektleiterEmail" className="text-gray-700 dark:text-gray-300">E-Mail</Label>
                    <Input
                      id="projektleiterEmail"
                      name="projektleiterEmail"
                      value={formData.projektleiterEmail}
                      onChange={handleChange}
                      placeholder="max@firma.de"
                      className="rounded-xl border-2 bg-white dark:bg-gray-800 dark:border-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-primary focus:border-primary"
                      type="email"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="projektleiterNotizen" className="text-gray-700 dark:text-gray-300">Notizen</Label>
                  <Textarea
                    id="projektleiterNotizen"
                    name="projektleiterNotizen"
                    value={formData.projektleiterNotizen}
                    onChange={handleChange}
                    placeholder="Zusätzliche Informationen über den Projektleiter..."
                    className="rounded-xl border-2 bg-white dark:bg-gray-800 dark:border-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-primary focus:border-primary"
                    rows={3}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Aktionen */}
            <div className="flex justify-end space-x-4">
              <Button variant="outline" type="button" asChild className="modern-button-secondary px-6 py-3">
                <Link href="/firmen">Abbrechen</Link>
              </Button>
              <Button 
                type="submit" 
                disabled={isLoading || !formData.name.trim()} 
                className="modern-button-primary px-6 py-3"
              >
                {isLoading ? (
                  <>
                    <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
                    Erstelle...
                  </>
                ) : (
                  <>
                    <Save className="mr-2 h-4 w-4" />
                    Firma erstellen
                  </>
                )}
              </Button>
            </div>
          </form>
        </div>
      </div>
    </div>
  )
}
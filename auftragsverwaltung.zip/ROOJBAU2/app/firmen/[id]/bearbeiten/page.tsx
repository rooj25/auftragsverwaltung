'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Toast } from '@/components/ui/toast'
import { ArrowLeft, Save, Trash2, Users, Plus } from 'lucide-react'
import Link from 'next/link'

interface Projektleiter {
  id: string
  vorname: string
  nachname: string
  telefon?: string
  email?: string
  position?: string
  notizen?: string
}

interface Firma {
  id: string
  name: string
  adresse?: string
  telefon?: string
  email?: string
  website?: string
  notizen?: string
  projektleiter: Projektleiter[]
}

export default function FirmaBearbeitenPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const queryClient = useQueryClient()
  const [isLoading, setIsLoading] = useState(false)
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null)
  const [formData, setFormData] = useState({
    name: '',
    adresse: '',
    telefon: '',
    email: '',
    website: '',
    notizen: ''
  })

  const { data: firma, isLoading: isLoadingFirma, error } = useQuery({
    queryKey: ['firma', params.id],
    queryFn: async () => {
      const response = await fetch(`/api/firmen/${params.id}`)
      if (!response.ok) {
        throw new Error('Firma nicht gefunden')
      }
      return response.json() as Promise<Firma>
    }
  })

  useEffect(() => {
    if (firma) {
      setFormData({
        name: firma.name || '',
        adresse: firma.adresse || '',
        telefon: firma.telefon || '',
        email: firma.email || '',
        website: firma.website || '',
        notizen: firma.notizen || ''
      })
    }
  }, [firma])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      console.log('Sending data:', formData) // Debug log
      
      const response = await fetch(`/api/firmen/${params.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          name: formData.name.trim(),
          adresse: formData.adresse.trim() || undefined,
          telefon: formData.telefon.trim() || undefined,
          email: formData.email.trim() || undefined,
          website: formData.website.trim() || undefined,
          notizen: formData.notizen.trim() || undefined,
        }),
      })

      console.log('Response status:', response.status) // Debug log

      if (!response.ok) {
        const errorData = await response.json()
        console.error('Server error:', errorData) // Debug log
        throw new Error(errorData.error || 'Fehler beim Aktualisieren der Firma')
      }

      const updatedFirma = await response.json()
      console.log('Updated firma:', updatedFirma) // Debug log
      
      // Invalidate queries to refresh data
      queryClient.invalidateQueries({ queryKey: ['firma', params.id] })
      queryClient.invalidateQueries({ queryKey: ['firmen'] })
      
      // Success message
      setToast({ message: 'Firma wurde erfolgreich aktualisiert!', type: 'success' })
      
      // Navigate after a short delay to show the toast
      setTimeout(() => {
        router.push(`/firmen/${params.id}`)
      }, 1500)
    } catch (error) {
      console.error('Fehler beim Aktualisieren der Firma:', error)
      setToast({ 
        message: `Fehler beim Aktualisieren: ${error instanceof Error ? error.message : 'Unbekannter Fehler'}`, 
        type: 'error' 
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleDelete = async () => {
    if (!confirm('Sind Sie sicher, dass Sie diese Firma löschen möchten? Diese Aktion kann nicht rückgängig gemacht werden.')) {
      return
    }

    setIsLoading(true)

    try {
      const response = await fetch(`/api/firmen/${params.id}`, {
        method: 'DELETE',
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.error || 'Fehler beim Löschen der Firma')
      }

      router.push('/firmen')
    } catch (error) {
      console.error('Fehler beim Löschen der Firma:', error)
      alert('Fehler beim Löschen der Firma. Bitte versuchen Sie es erneut.')
    } finally {
      setIsLoading(false)
    }
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData(prev => ({ ...prev, [name]: value }))
  }

  if (isLoadingFirma) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gradient-to-br dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 transition-colors duration-300 p-6">
        <div className="flex items-center space-x-4 mb-8">
          <div className="h-10 w-20 bg-gray-200 dark:bg-gray-700 rounded-xl animate-pulse"></div>
          <div className="h-8 w-48 bg-gray-200 dark:bg-gray-700 rounded-xl animate-pulse"></div>
        </div>
        <div className="max-w-2xl">
          <Card className="dark-card-modern animate-pulse">
            <CardHeader>
              <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded w-1/3 mb-2"></div>
              <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-1/2"></div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[...Array(6)].map((_, i) => (
                  <div key={i} className="space-y-2">
                    <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-1/4"></div>
                    <div className="h-10 bg-gray-200 dark:bg-gray-700 rounded"></div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  if (error || !firma) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gradient-to-br dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 transition-colors duration-300 p-6">
        <div className="flex items-center space-x-4 mb-8">
          <Button variant="ghost" size="sm" asChild className="text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800">
            <Link href="/firmen">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Zurück
            </Link>
          </Button>
        </div>
        <Card className="dark-card-modern">
          <CardContent className="pt-6 text-center">
            <h3 className="text-lg font-medium mb-2 text-gray-900 dark:text-white">Firma nicht gefunden</h3>
            <p className="text-gray-600 dark:text-gray-400 mb-4">Die angeforderte Firma konnte nicht geladen werden.</p>
            <Button asChild className="modern-button-primary">
              <Link href="/firmen">Zurück zur Firmenliste</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gradient-to-br dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 transition-colors duration-300 p-6">
      {/* Toast */}
      {toast && (
        <Toast 
          message={toast.message} 
          type={toast.type} 
          onClose={() => setToast(null)} 
        />
      )}
      
      {/* Header */}
      <div className="flex items-center space-x-4 mb-8">
        <Button variant="ghost" size="sm" asChild className="text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800">
            <Link href={`/firmen/${params.id}`}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Zurück zu {firma.name}
          </Link>
        </Button>
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
            Firma bearbeiten
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            Aktualisieren Sie die Informationen von {firma.name}
          </p>
        </div>
      </div>

      {/* Formular */}
      <div className="max-w-2xl mx-auto">
        <form onSubmit={handleSubmit}>
          <Card className="dark-card-modern">
            <CardHeader>
              <CardTitle className="text-xl text-gray-900 dark:text-white">Firmeninformationen</CardTitle>
              <CardDescription className="text-gray-600 dark:text-gray-400">
                Bearbeiten Sie die grundlegenden Informationen der Firma
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="name" className="text-gray-700 dark:text-gray-300">Firmenname *</Label>
                <Input
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  placeholder="z.B. TechCorp GmbH"
                  className="rounded-xl border-2 bg-white dark:bg-gray-800 dark:border-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-primary focus:border-primary"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="adresse" className="text-gray-700 dark:text-gray-300">Adresse</Label>
                <Textarea
                  id="adresse"
                  name="adresse"
                  value={formData.adresse}
                  onChange={handleChange}
                  placeholder="Straße, PLZ Stadt"
                  className="rounded-xl border-2 bg-white dark:bg-gray-800 dark:border-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-primary focus:border-primary"
                  rows={2}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="telefon" className="text-gray-700 dark:text-gray-300">Telefon</Label>
                  <Input
                    id="telefon"
                    name="telefon"
                    value={formData.telefon}
                    onChange={handleChange}
                    placeholder="+49 30 12345678"
                    className="rounded-xl border-2 bg-white dark:bg-gray-800 dark:border-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-primary focus:border-primary"
                    type="tel"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email" className="text-gray-700 dark:text-gray-300">E-Mail</Label>
                  <Input
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="info@firma.de"
                    className="rounded-xl border-2 bg-white dark:bg-gray-800 dark:border-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-primary focus:border-primary"
                    type="email"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="website" className="text-gray-700 dark:text-gray-300">Website</Label>
                <Input
                  id="website"
                  name="website"
                  value={formData.website}
                  onChange={handleChange}
                  placeholder="https://www.firma.de"
                  className="rounded-xl border-2 bg-white dark:bg-gray-800 dark:border-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-primary focus:border-primary"
                  type="url"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="notizen" className="text-gray-700 dark:text-gray-300">Notizen</Label>
                <Textarea
                  id="notizen"
                  name="notizen"
                  value={formData.notizen}
                  onChange={handleChange}
                  placeholder="Zusätzliche Informationen über die Firma..."
                  className="rounded-xl border-2 bg-white dark:bg-gray-800 dark:border-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-primary focus:border-primary"
                  rows={4}
                />
              </div>
            </CardContent>
          </Card>

          {/* Projektleiter Verwaltung */}
          <Card className="mt-6 dark-card-modern">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center text-xl text-gray-900 dark:text-white">
                    <div className="fintech-kpi-card p-2 neon-glow-blue mr-3">
                      <Users className="h-5 w-5 text-white" />
                    </div>
                    Projektleiter ({firma?.projektleiter?.length || 0})
                  </CardTitle>
                  <CardDescription className="text-gray-600 dark:text-gray-400">
                    Verwalten Sie die Projektleiter für diese Firma
                  </CardDescription>
                </div>
                <Button 
                  asChild 
                  className="modern-button-secondary rounded-xl"
                >
                  <Link href={`/projektleiter/neu?firmaId=${params.id}&firmaName=${encodeURIComponent(formData.name)}`}>
                    <Plus className="mr-2 h-4 w-4" />
                    Hinzufügen
                  </Link>
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {!firma?.projektleiter || firma.projektleiter.length === 0 ? (
                <div className="text-center py-8 text-gray-700 dark:text-gray-300">
                  <Users className="mx-auto h-12 w-12 text-gray-400 dark:text-gray-500 mb-4" />
                  <h4 className="text-lg font-medium mb-2">Keine Projektleiter</h4>
                  <p className="text-gray-600 dark:text-gray-400 mb-4">
                    Fügen Sie den ersten Projektleiter für diese Firma hinzu
                  </p>
                  <Button asChild className="modern-button-primary">
                    <Link href={`/projektleiter/neu?firmaId=${params.id}&firmaName=${encodeURIComponent(formData.name)}`}>
                      <Users className="mr-2 h-4 w-4" />
                      Ersten Projektleiter hinzufügen
                    </Link>
                  </Button>
                </div>
              ) : (
                <div className="space-y-4">
                  {firma.projektleiter.map((projektleiter) => (
                    <div key={projektleiter.id} className="p-4 bg-gray-50 dark:bg-gray-800 rounded-xl hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h4 className="font-semibold text-lg text-gray-900 dark:text-white">
                            {projektleiter.vorname} {projektleiter.nachname}
                          </h4>
                          {projektleiter.position && (
                            <p className="text-gray-600 dark:text-gray-400 mb-2">{projektleiter.position}</p>
                          )}
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
                            {projektleiter.telefon && (
                              <div className="flex items-center text-gray-600 dark:text-gray-400">
                                <span className="font-medium w-16">Tel:</span>
                                <span>{projektleiter.telefon}</span>
                              </div>
                            )}
                            {projektleiter.email && (
                              <div className="flex items-center text-gray-600 dark:text-gray-400">
                                <span className="font-medium w-16">E-Mail:</span>
                                <span>{projektleiter.email}</span>
                              </div>
                            )}
                          </div>
                          {projektleiter.notizen && (
                            <div className="mt-2 pt-2 border-t border-gray-200 dark:border-gray-700">
                              <p className="text-sm text-gray-600 dark:text-gray-400">
                                <span className="font-medium">Notizen:</span> {projektleiter.notizen}
                              </p>
                            </div>
                          )}
                        </div>
                        <div className="flex space-x-2 ml-4">
                          <Button 
                            size="sm" 
                            asChild
                            className="modern-button-secondary rounded-lg"
                          >
                            <Link href={`/projektleiter/${projektleiter.id}/bearbeiten`}>
                              Bearbeiten
                            </Link>
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Aktionen */}
          <div className="flex justify-between mt-6">
            <Button 
              variant="destructive" 
              type="button" 
              onClick={handleDelete}
              disabled={isLoading}
              className="rounded-xl"
            >
              <Trash2 className="mr-2 h-4 w-4" />
              Firma löschen
            </Button>
            
            <div className="flex space-x-4">
              <Button type="button" asChild className="modern-button-secondary rounded-xl">
                <Link href={`/firmen/${params.id}`}>Abbrechen</Link>
              </Button>
              <Button 
                type="submit" 
                disabled={isLoading || !formData.name.trim()}
                className="modern-button-primary rounded-xl"
              >
                {isLoading ? (
                  <>
                    <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
                    Speichere...
                  </>
                ) : (
                  <>
                    <Save className="mr-2 h-4 w-4" />
                    Änderungen speichern
                  </>
                )}
              </Button>
            </div>
          </div>
        </form>
      </div>
    </div>
  )
}

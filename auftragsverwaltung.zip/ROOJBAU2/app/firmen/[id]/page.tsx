'use client'

import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { ArrowLeft, Edit, Plus, Phone, Mail, Globe, MapPin, Users, FileText, Calendar } from 'lucide-react'
import Link from 'next/link'
import { getStatusColor, getStatusText, getPriorityColor, getPriorityText, formatDate, formatCurrency } from '@/lib/utils'

interface Projektleiter {
  id: string
  vorname: string
  nachname: string
  telefon?: string
  email?: string
  position?: string
  notizen?: string
}

interface Auftrag {
  id: string
  auftragsnummer: string
  titel: string
  beschreibung?: string
  status: string
  prioritaet: string
  startdatum?: string
  geplantesEnddatum?: string
  kosten?: number
  erstelltAm: string
  projektleiter?: Projektleiter
}

interface Firma {
  id: string
  name: string
  adresse?: string
  telefon?: string
  email?: string
  website?: string
  notizen?: string
  erstelltAm: string
  projektleiter: Projektleiter[]
  auftraege: Auftrag[]
}

export default function FirmaDetailPage({ params }: { params: { id: string } }) {
  const { data: firma, isLoading, error } = useQuery({
    queryKey: ['firma', params.id],
    queryFn: async () => {
      const response = await fetch(`/api/firmen/${params.id}`)
      if (!response.ok) {
        throw new Error('Firma nicht gefunden')
      }
      return response.json() as Promise<Firma>
    }
  })

  if (isLoading) {
    return (
      <div className="min-h-screen">
        <div className="spacing-4 lg:spacing-6">
          <div className="text-center space-y-4">
            <div className="fintech-kpi-card spacing-4 max-w-md mx-auto">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-cyan-400 mx-auto mb-4"></div>
              <p className="body-medium text-gray-400">Firma wird geladen...</p>
            </div>
          </div>
        </div>
      </div>
    )
  }

  if (error || !firma) {
    return (
      <div className="min-h-screen">
        <div className="spacing-4 lg:spacing-6">
          <div className="flex items-center space-x-4 mb-8">
            <Link href="/firmen">
              <div className="ios-button-secondary p-2 micro-bounce">
                <ArrowLeft className="h-4 w-4" />
              </div>
            </Link>
            <h1 className="headline-large font-bold text-gray-900 dark:text-white">Firma nicht gefunden</h1>
          </div>
          <div className="text-center">
            <div className="fintech-card spacing-4 max-w-md mx-auto">
              <h3 className="title-large font-bold text-white mb-2">Firma nicht gefunden</h3>
              <p className="body-medium text-gray-400 mb-6">Die angeforderte Firma konnte nicht geladen werden.</p>
              <Link href="/firmen">
                <div className="fintech-button-primary micro-bounce">
                  Zurück zur Firmenliste
                </div>
              </Link>
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen">
      {/* Header */}
      <div className="spacing-4 lg:spacing-6">
        <div className="flex flex-col space-y-4 lg:flex-row lg:items-center lg:justify-between lg:space-y-0">
          <div className="flex items-center space-x-4">
            <Link href="/firmen">
              <div className="ios-button-secondary p-2 micro-bounce">
                <ArrowLeft className="h-4 w-4" />
              </div>
            </Link>
            <div>
              <h1 className="display-small font-bold bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent">
                {firma.name}
              </h1>
              <p className="body-medium text-gray-600 dark:text-gray-400">
                Erstellt am {formatDate(firma.erstelltAm)}
              </p>
            </div>
          </div>
          <div className="flex space-x-3">
            <Link href={`/firmen/${firma.id}/bearbeiten`}>
              <div className="ios-button-secondary micro-bounce">
                <Edit className="mr-2 h-4 w-4" />
                Bearbeiten
              </div>
            </Link>
            <Link href={`/auftraege/neu?firmaId=${firma.id}`}>
              <div className="fintech-button-primary micro-slide-up neon-glow-purple">
                <Plus className="mr-2 h-4 w-4" />
                Neuer Auftrag
              </div>
            </Link>
          </div>
        </div>
      </div>

      <div className="spacing-4 lg:spacing-6">
        <div className="grid gap-8 lg:grid-cols-3">
          {/* Firmeninformationen */}
          <div className="lg:col-span-2 space-y-6">
            <div className="m3-card-elevated spacing-4 micro-slide-up">
              <div className="flex items-center space-x-3 mb-6">
                <div className="fintech-kpi-card p-3 neon-glow-cyan">
                  <MapPin className="h-6 w-6 text-cyan-400" />
                </div>
                <div>
                  <h2 className="headline-small font-bold text-gray-900 dark:text-white">Firmeninformationen</h2>
                </div>
              </div>
              
              <div className="space-y-4">
                {firma.adresse && (
                  <div className="flex items-start space-x-3 p-3 bg-gray-50 dark:bg-gray-800/50 rounded-xl">
                    <MapPin className="h-5 w-5 text-gray-400 dark:text-gray-500 mt-0.5" />
                    <div>
                      <p className="label-large font-semibold text-gray-900 dark:text-white">Adresse</p>
                      <p className="body-medium text-gray-700 dark:text-gray-300">{firma.adresse}</p>
                    </div>
                  </div>
                )}
                
                {firma.telefon && (
                  <div className="flex items-center space-x-3 p-3 bg-gray-50 dark:bg-gray-800/50 rounded-xl">
                    <Phone className="h-5 w-5 text-gray-400 dark:text-gray-500" />
                    <div>
                      <p className="label-large font-semibold text-gray-900 dark:text-white">Telefon</p>
                      <p className="body-medium text-gray-700 dark:text-gray-300">{firma.telefon}</p>
                    </div>
                  </div>
                )}
                
                {firma.email && (
                  <div className="flex items-center space-x-3 p-3 bg-gray-50 dark:bg-gray-800/50 rounded-xl">
                    <Mail className="h-5 w-5 text-gray-400 dark:text-gray-500" />
                    <div>
                      <p className="label-large font-semibold text-gray-900 dark:text-white">E-Mail</p>
                      <a href={`mailto:${firma.email}`} className="body-medium text-blue-400 hover:text-blue-300 transition-colors">
                        {firma.email}
                      </a>
                    </div>
                  </div>
                )}
                
                {firma.website && (
                  <div className="flex items-center space-x-3 p-3 bg-gray-50 dark:bg-gray-800/50 rounded-xl">
                    <Globe className="h-5 w-5 text-gray-400 dark:text-gray-500" />
                    <div>
                      <p className="label-large font-semibold text-gray-900 dark:text-white">Website</p>
                      <a 
                        href={firma.website.startsWith('http') ? firma.website : `https://${firma.website}`} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="body-medium text-blue-400 hover:text-blue-300 transition-colors"
                      >
                        {firma.website}
                      </a>
                    </div>
                  </div>
                )}
                
                {firma.notizen && (
                  <div className="p-4 bg-gray-50 dark:bg-gray-800/50 rounded-xl">
                    <p className="label-large font-semibold text-gray-900 dark:text-white mb-2">Notizen</p>
                    <p className="body-medium text-gray-700 dark:text-gray-300 whitespace-pre-wrap">{firma.notizen}</p>
                  </div>
                )}
              </div>
            </div>

            {/* Aufträge */}
            <div className="fintech-card spacing-4 micro-slide-up">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center space-x-3">
                  <div className="fintech-kpi-card p-3 neon-glow-purple">
                    <FileText className="h-6 w-6 text-purple-400" />
                  </div>
                  <div>
                    <h2 className="headline-small font-bold text-white">Aufträge ({firma.auftraege.length})</h2>
                  </div>
                </div>
                <Link href={`/auftraege/neu?firmaId=${firma.id}`}>
                  <div className="fintech-button-primary micro-bounce">
                    <Plus className="h-4 w-4" />
                  </div>
                </Link>
              </div>
              
              {firma.auftraege.length === 0 ? (
                <div className="text-center py-8">
                  <div className="fintech-kpi-card p-4 mx-auto w-fit mb-4">
                    <FileText className="h-8 w-8 text-purple-400" />
                  </div>
                  <p className="body-medium text-gray-400 mb-6">Noch keine Aufträge für diese Firma</p>
                  <Link href={`/auftraege/neu?firmaId=${firma.id}`}>
                    <div className="fintech-button-primary micro-bounce">
                      Ersten Auftrag erstellen
                    </div>
                  </Link>
                </div>
              ) : (
                <div className="space-y-3">
                  {firma.auftraege.map((auftrag) => (
                    <div key={auftrag.id} className="p-4 bg-white/5 rounded-xl hover:bg-white/10 transition-all duration-300 micro-bounce">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <div className="flex items-center space-x-2 mb-1">
                            <h4 className="title-medium font-bold text-white">{auftrag.titel}</h4>
                            <Badge className={getStatusColor(auftrag.status)} variant="outline">
                              {getStatusText(auftrag.status)}
                            </Badge>
                            <Badge className={getPriorityColor(auftrag.prioritaet)} variant="outline">
                              {getPriorityText(auftrag.prioritaet)}
                            </Badge>
                          </div>
                          <p className="body-small text-gray-400 font-mono">{auftrag.auftragsnummer}</p>
                        </div>
                        <Link href={`/auftraege/${auftrag.id}`}>
                          <div className="ios-button-secondary px-3 py-2 text-xs micro-bounce">
                            Details
                          </div>
                        </Link>
                      </div>
                      
                      {auftrag.beschreibung && (
                        <p className="body-small text-gray-300 mb-3 line-clamp-2">{auftrag.beschreibung}</p>
                      )}
                      
                      <div className="flex flex-wrap gap-4 text-xs text-gray-400">
                        {auftrag.projektleiter && (
                          <span>Projektleiter: {auftrag.projektleiter.vorname} {auftrag.projektleiter.nachname}</span>
                        )}
                        {auftrag.geplantesEnddatum && (
                          <span>Bis: {formatDate(auftrag.geplantesEnddatum)}</span>
                        )}
                        {auftrag.kosten && (
                          <span>Kosten: {formatCurrency(auftrag.kosten)}</span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Projektleiter */}
            <div className="ios-card spacing-4 micro-slide-up">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center space-x-3">
                  <div className="fintech-kpi-card p-3 neon-glow-blue">
                    <Users className="h-6 w-6 text-blue-400" />
                  </div>
                  <div>
                    <h3 className="title-large font-bold text-gray-900 dark:text-white">Projektleiter ({firma.projektleiter.length})</h3>
                  </div>
                </div>
                <Link href={`/projektleiter/neu?firmaId=${firma.id}&firmaName=${encodeURIComponent(firma.name)}`}>
                  <div className="ios-button-secondary p-2 micro-bounce">
                    <Plus className="h-4 w-4" />
                  </div>
                </Link>
              </div>
              
              {firma.projektleiter.length === 0 ? (
                <div className="text-center py-6">
                  <div className="fintech-kpi-card p-3 mx-auto w-fit mb-4">
                    <Users className="h-6 w-6 text-blue-400" />
                  </div>
                  <p className="body-medium text-gray-600 dark:text-gray-400 mb-4">Keine Projektleiter</p>
                  <Link href={`/projektleiter/neu?firmaId=${firma.id}&firmaName=${encodeURIComponent(firma.name)}`}>
                    <div className="m3-button-outlined micro-bounce">
                      Hinzufügen
                    </div>
                  </Link>
                </div>
              ) : (
                <div className="space-y-3">
                  {firma.projektleiter.map((projektleiter) => (
                    <div key={projektleiter.id} className="p-3 bg-gray-50 dark:bg-gray-800/50 rounded-xl hover:bg-gray-100 dark:hover:bg-gray-700/50 transition-all duration-300">
                      <h4 className="title-medium font-bold text-gray-900 dark:text-white">
                        {projektleiter.vorname} {projektleiter.nachname}
                      </h4>
                      {projektleiter.position && (
                        <p className="body-small text-gray-600 dark:text-gray-400 mt-1">{projektleiter.position}</p>
                      )}
                      <div className="mt-2 space-y-1">
                        {projektleiter.telefon && (
                          <div className="flex items-center space-x-2">
                            <Phone className="h-3 w-3 text-gray-500" />
                            <span className="body-small text-gray-500 dark:text-gray-400">{projektleiter.telefon}</span>
                          </div>
                        )}
                        {projektleiter.email && (
                          <div className="flex items-center space-x-2">
                            <Mail className="h-3 w-3 text-gray-500" />
                            <span className="body-small text-gray-500 dark:text-gray-400">{projektleiter.email}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Statistiken */}
            <div className="m3-card-filled spacing-4 micro-slide-up">
              <div className="flex items-center space-x-3 mb-4">
                <div className="fintech-kpi-card p-3">
                  <Calendar className="h-6 w-6 text-orange-400" />
                </div>
                <h3 className="title-large font-bold text-gray-900 dark:text-white">Statistiken</h3>
              </div>
              
              <div className="space-y-4">
                <div className="flex items-center justify-between p-3 bg-white/50 dark:bg-white/5 rounded-xl">
                  <span className="body-medium text-gray-700 dark:text-gray-300">Projektleiter</span>
                  <div className="flex items-center space-x-2">
                    <span className="title-medium font-bold text-gray-900 dark:text-white">{firma.projektleiter.length}</span>
                    <div className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse"></div>
                  </div>
                </div>
                <div className="flex items-center justify-between p-3 bg-white/50 dark:bg-white/5 rounded-xl">
                  <span className="body-medium text-gray-700 dark:text-gray-300">Aufträge gesamt</span>
                  <div className="flex items-center space-x-2">
                    <span className="title-medium font-bold text-gray-900 dark:text-white">{firma.auftraege.length}</span>
                    <div className="w-2 h-2 rounded-full bg-purple-400 animate-pulse"></div>
                  </div>
                </div>
                <div className="flex items-center justify-between p-3 bg-white/50 dark:bg-white/5 rounded-xl">
                  <span className="body-medium text-gray-700 dark:text-gray-300">Aktive Aufträge</span>
                  <div className="flex items-center space-x-2">
                    <span className="title-medium font-bold text-gray-900 dark:text-white">
                      {firma.auftraege.filter(a => a.status === 'IN_BEARBEITUNG').length}
                    </span>
                    <div className="w-2 h-2 rounded-full bg-blue-400 animate-pulse"></div>
                  </div>
                </div>
                <div className="flex items-center justify-between p-3 bg-white/50 dark:bg-white/5 rounded-xl">
                  <span className="body-medium text-gray-700 dark:text-gray-300">Abgeschlossen</span>
                  <div className="flex items-center space-x-2">
                    <span className="title-medium font-bold text-gray-900 dark:text-white">
                      {firma.auftraege.filter(a => a.status === 'ABGESCHLOSSEN').length}
                    </span>
                    <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
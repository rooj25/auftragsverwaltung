import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { z } from 'zod'

const ProjektleiterSchema = z.object({
  vorname: z.string().min(1, 'Vorname ist erforderlich'),
  nachname: z.string().min(1, 'Nachname ist erforderlich'),
  telefon: z.string().optional(),
  email: z.string().email('Ungültige E-Mail-Adresse').optional().or(z.literal('').transform(() => undefined)),
  position: z.string().optional(),
  notizen: z.string().optional(),
  firmaId: z.string().min(1, 'Firma ist erforderlich'),
}).transform((data) => {
  // Entferne leere Strings und ersetze sie mit undefined
  return {
    vorname: data.vorname,
    nachname: data.nachname,
    telefon: data.telefon || undefined,
    email: data.email || undefined,
    position: data.position || undefined,
    notizen: data.notizen || undefined,
    firmaId: data.firmaId,
  }
})

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const firmaId = searchParams.get('firmaId')

    const where = firmaId ? { firmaId } : {}

    const projektleiter = await prisma.projektleiter.findMany({
      where,
      include: {
        firma: true,
        auftraege: {
          orderBy: {
            erstelltAm: 'desc'
          }
        },
        _count: {
          select: {
            auftraege: true
          }
        }
      },
      orderBy: [
        { nachname: 'asc' },
        { vorname: 'asc' }
      ]
    })

    return NextResponse.json(projektleiter)
  } catch (error) {
    console.error('Fehler beim Laden der Projektleiter:', error)
    return NextResponse.json(
      { error: 'Fehler beim Laden der Projektleiter' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    
    const validatedData = ProjektleiterSchema.parse(body)
    
    const projektleiter = await prisma.projektleiter.create({
      data: validatedData,
      include: {
        firma: true,
        auftraege: true
      }
    })

    return NextResponse.json(projektleiter, { status: 201 })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Ungültige Daten', details: error.errors },
        { status: 400 }
      )
    }

    console.error('Fehler beim Erstellen des Projektleiters:', error)
    return NextResponse.json(
      { error: 'Fehler beim Erstellen des Projektleiters' },
      { status: 500 }
    )
  }
}

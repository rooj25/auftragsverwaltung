import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { z } from 'zod'

const ProjektleiterUpdateSchema = z.object({
  vorname: z.string().min(1, 'Vorname ist erforderlich'),
  nachname: z.string().min(1, 'Nachname ist erforderlich'),
  telefon: z.string().optional(),
  email: z.string().email('Ungültige E-Mail-Adresse').optional().or(z.literal('').transform(() => undefined)),
  position: z.string().optional(),
  notizen: z.string().optional(),
}).transform((data) => {
  // Entferne leere Strings und ersetze sie mit undefined
  return {
    vorname: data.vorname,
    nachname: data.nachname,
    telefon: data.telefon || undefined,
    email: data.email || undefined,
    position: data.position || undefined,
    notizen: data.notizen || undefined,
  }
})

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const projektleiter = await prisma.projektleiter.findUnique({
      where: { id: params.id },
      include: {
        firma: true,
        auftraege: {
          orderBy: {
            erstelltAm: 'desc'
          }
        }
      }
    })

    if (!projektleiter) {
      return NextResponse.json(
        { error: 'Projektleiter nicht gefunden' },
        { status: 404 }
      )
    }

    return NextResponse.json(projektleiter)
  } catch (error) {
    console.error('Fehler beim Laden des Projektleiters:', error)
    return NextResponse.json(
      { error: 'Fehler beim Laden des Projektleiters' },
      { status: 500 }
    )
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    console.log('PUT request received for projektleiter ID:', params.id)
    
    const body = await request.json()
    console.log('Request body:', body)
    
    // Überprüfe ob der Projektleiter existiert
    const existingProjektleiter = await prisma.projektleiter.findUnique({
      where: { id: params.id }
    })
    
    if (!existingProjektleiter) {
      console.log('Projektleiter not found:', params.id)
      return NextResponse.json(
        { error: 'Projektleiter nicht gefunden' },
        { status: 404 }
      )
    }
    
    const validatedData = ProjektleiterUpdateSchema.parse(body)
    console.log('Validated data:', validatedData)
    
    const projektleiter = await prisma.projektleiter.update({
      where: { id: params.id },
      data: validatedData,
      include: {
        firma: true,
        auftraege: true
      }
    })

    console.log('Projektleiter updated successfully:', projektleiter.vorname, projektleiter.nachname)
    return NextResponse.json(projektleiter)
  } catch (error) {
    if (error instanceof z.ZodError) {
      console.error('Validation error:', error.errors)
      return NextResponse.json(
        { error: 'Ungültige Daten', details: error.errors },
        { status: 400 }
      )
    }

    console.error('Fehler beim Aktualisieren des Projektleiters:', error)
    return NextResponse.json(
      { error: 'Fehler beim Aktualisieren des Projektleiters', details: error },
      { status: 500 }
    )
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    // Überprüfe ob der Projektleiter existiert
    const existingProjektleiter = await prisma.projektleiter.findUnique({
      where: { id: params.id }
    })
    
    if (!existingProjektleiter) {
      return NextResponse.json(
        { error: 'Projektleiter nicht gefunden' },
        { status: 404 }
      )
    }

    await prisma.projektleiter.delete({
      where: { id: params.id }
    })

    console.log('Projektleiter deleted successfully:', params.id)
    return NextResponse.json({ message: 'Projektleiter erfolgreich gelöscht' })
  } catch (error) {
    console.error('Fehler beim Löschen des Projektleiters:', error)
    return NextResponse.json(
      { error: 'Fehler beim Löschen des Projektleiters' },
      { status: 500 }
    )
  }
}


import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { z } from 'zod'

const FirmaSchema = z.object({
  name: z.string().min(1, 'Name ist erforderlich'),
  adresse: z.string().optional(),
  telefon: z.string().optional(),
  email: z.string().email('Ungültige E-Mail-Adresse').optional().or(z.literal('')),
  website: z.string().optional(),
  notizen: z.string().optional(),
})

export async function GET() {
  try {
    const firmen = await prisma.firma.findMany({
      include: {
        projektleiter: true,
        auftraege: {
          orderBy: {
            erstelltAm: 'desc'
          }
        },
        _count: {
          select: {
            projektleiter: true,
            auftraege: true
          }
        }
      },
      orderBy: {
        name: 'asc'
      }
    })

    return NextResponse.json(firmen)
  } catch (error) {
    console.error('Fehler beim Laden der Firmen:', error)
    return NextResponse.json(
      { error: 'Fehler beim Laden der Firmen' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    
    const validatedData = FirmaSchema.parse(body)
    
    const firma = await prisma.firma.create({
      data: validatedData,
      include: {
        projektleiter: true,
        auftraege: true,
        _count: {
          select: {
            projektleiter: true,
            auftraege: true
          }
        }
      }
    })

    return NextResponse.json(firma, { status: 201 })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Ungültige Daten', details: error.errors },
        { status: 400 }
      )
    }

    console.error('Fehler beim Erstellen der Firma:', error)
    return NextResponse.json(
      { error: 'Fehler beim Erstellen der Firma' },
      { status: 500 }
    )
  }
}


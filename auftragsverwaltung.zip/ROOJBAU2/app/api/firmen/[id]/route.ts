import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { z } from 'zod'

const FirmaUpdateSchema = z.object({
  name: z.string().min(1, 'Name ist erforderlich'),
  adresse: z.string().optional(),
  telefon: z.string().optional(),
  email: z.string().email('Ungültige E-Mail-Adresse').optional().or(z.literal('').transform(() => undefined)),
  website: z.string().optional(),
  notizen: z.string().optional(),
}).transform((data) => {
  // Entferne leere Strings und ersetze sie mit undefined
  return {
    name: data.name,
    adresse: data.adresse || undefined,
    telefon: data.telefon || undefined,
    email: data.email || undefined,
    website: data.website || undefined,
    notizen: data.notizen || undefined,
  }
})

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const firma = await prisma.firma.findUnique({
      where: { id: params.id },
      include: {
        projektleiter: {
          orderBy: {
            nachname: 'asc'
          }
        },
        auftraege: {
          orderBy: {
            erstelltAm: 'desc'
          },
          include: {
            projektleiter: true
          }
        }
      }
    })

    if (!firma) {
      return NextResponse.json(
        { error: 'Firma nicht gefunden' },
        { status: 404 }
      )
    }

    return NextResponse.json(firma)
  } catch (error) {
    console.error('Fehler beim Laden der Firma:', error)
    return NextResponse.json(
      { error: 'Fehler beim Laden der Firma' },
      { status: 500 }
    )
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    console.log('PUT request received for firma ID:', params.id) // Debug log
    
    const body = await request.json()
    console.log('Request body:', body) // Debug log
    
    // Überprüfe ob die Firma existiert
    const existingFirma = await prisma.firma.findUnique({
      where: { id: params.id }
    })
    
    if (!existingFirma) {
      console.log('Firma not found:', params.id) // Debug log
      return NextResponse.json(
        { error: 'Firma nicht gefunden' },
        { status: 404 }
      )
    }
    
    const validatedData = FirmaUpdateSchema.parse(body)
    console.log('Validated data:', validatedData) // Debug log
    
    const firma = await prisma.firma.update({
      where: { id: params.id },
      data: validatedData,
      include: {
        projektleiter: true,
        auftraege: true
      }
    })

    console.log('Firma updated successfully:', firma.name) // Debug log
    return NextResponse.json(firma)
  } catch (error) {
    if (error instanceof z.ZodError) {
      console.error('Validation error:', error.errors) // Debug log
      return NextResponse.json(
        { error: 'Ungültige Daten', details: error.errors },
        { status: 400 }
      )
    }

    console.error('Fehler beim Aktualisieren der Firma:', error)
    return NextResponse.json(
      { error: 'Fehler beim Aktualisieren der Firma', details: error },
      { status: 500 }
    )
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    await prisma.firma.delete({
      where: { id: params.id }
    })

    return NextResponse.json({ message: 'Firma erfolgreich gelöscht' })
  } catch (error) {
    console.error('Fehler beim Löschen der Firma:', error)
    return NextResponse.json(
      { error: 'Fehler beim Löschen der Firma' },
      { status: 500 }
    )
  }
}

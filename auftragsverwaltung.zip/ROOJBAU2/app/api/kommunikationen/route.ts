import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { z } from 'zod'

const KommunikationSchema = z.object({
  typ: z.enum(['ANRUF', 'EMAIL', 'MEETING', 'NOTIZ']),
  richtung: z.enum(['EINGEHEND', 'AUSGEHEND']),
  betreff: z.string().optional(),
  inhalt: z.string().optional(),
  datum: z.string().datetime().optional(),
  dauer: z.number().int().min(0).optional(),
  auftragId: z.string().min(1, 'Auftrag ist erforderlich'),
  kontaktpersonId: z.string().optional(),
})

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const auftragId = searchParams.get('auftragId')
    const kontaktpersonId = searchParams.get('kontaktpersonId')

    let whereClause: any = {}
    
    if (auftragId) {
      whereClause.auftragId = auftragId
    }
    
    if (kontaktpersonId) {
      whereClause.kontaktpersonId = kontaktpersonId
    }

    const kommunikationen = await prisma.kommunikation.findMany({
      where: whereClause,
      include: {
        kontaktperson: {
          select: {
            id: true,
            vorname: true,
            nachname: true,
            position: true
          }
        },
        auftrag: {
          select: {
            id: true,
            titel: true,
            auftragsnummer: true
          }
        }
      },
      orderBy: { datum: 'desc' }
    })

    return NextResponse.json(kommunikationen)
  } catch (error) {
    console.error('Fehler beim Laden der Kommunikationen:', error)
    return NextResponse.json(
      { error: 'Fehler beim Laden der Kommunikationen' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const validatedData = KommunikationSchema.parse(body)

    const kommunikation = await prisma.kommunikation.create({
      data: {
        typ: validatedData.typ,
        richtung: validatedData.richtung,
        betreff: validatedData.betreff,
        inhalt: validatedData.inhalt,
        datum: validatedData.datum ? new Date(validatedData.datum) : new Date(),
        dauer: validatedData.dauer,
        auftragId: validatedData.auftragId,
        kontaktpersonId: validatedData.kontaktpersonId,
      },
      include: {
        kontaktperson: {
          select: {
            id: true,
            vorname: true,
            nachname: true,
            position: true
          }
        }
      }
    })

    return NextResponse.json(kommunikation, { status: 201 })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Ungültige Daten', details: error.errors },
        { status: 400 }
      )
    }

    console.error('Fehler beim Erstellen der Kommunikation:', error)
    return NextResponse.json(
      { error: 'Fehler beim Erstellen der Kommunikation' },
      { status: 500 }
    )
  }
}


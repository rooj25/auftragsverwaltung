import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { z } from 'zod'

const AuftragUpdateSchema = z.object({
  titel: z.string().min(1, 'Titel ist erforderlich'),
  beschreibung: z.string().optional(),
  status: z.string().refine(val => ['NEU', 'IN_BEARBEITUNG', 'WARTEND', 'ABGESCHLOSSEN', 'STORNIERT'].includes(val), {
    message: 'Ungültiger Status'
  }),
  prioritaet: z.string().refine(val => ['NIEDRIG', 'NORMAL', 'HOCH', 'KRITISCH'].includes(val), {
    message: 'Ungültige Priorität'
  }),
  startdatum: z.string().optional(),
  geplantesEnddatum: z.string().optional(),
  geschaetzterAufwand: z.number().optional(),
  kosten: z.number().optional(),
  notizen: z.string().optional(),
  firmaId: z.string().min(1, 'Firma ist erforderlich'),
  projektleiterId: z.string().optional(),
}).transform((data) => {
  const result: any = {
    titel: data.titel,
    beschreibung: data.beschreibung || undefined,
    status: data.status,
    prioritaet: data.prioritaet,
    geschaetzterAufwand: data.geschaetzterAufwand || undefined,
    kosten: data.kosten || undefined,
    notizen: data.notizen || undefined,
    firmaId: data.firmaId,
    projektleiterId: data.projektleiterId || undefined,
  }
  
  if (data.startdatum) {
    result.startdatum = new Date(data.startdatum)
  }
  if (data.geplantesEnddatum) {
    result.geplantesEnddatum = new Date(data.geplantesEnddatum)
  }
  
  return result
})

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const auftrag = await prisma.auftrag.findUnique({
      where: { id: params.id },
      include: {
        firma: true,
        projektleiter: true,
        statusVerlauf: {
          orderBy: {
            erstelltAm: 'desc'
          }
        }
      }
    })

    if (!auftrag) {
      return NextResponse.json(
        { error: 'Auftrag nicht gefunden' },
        { status: 404 }
      )
    }

    return NextResponse.json(auftrag)
  } catch (error) {
    console.error('Fehler beim Laden des Auftrags:', error)
    return NextResponse.json(
      { error: 'Fehler beim Laden des Auftrags' },
      { status: 500 }
    )
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    console.log('PUT request received for auftrag ID:', params.id)
    
    const body = await request.json()
    console.log('Request body:', body)
    
    // Überprüfe ob der Auftrag existiert
    const existingAuftrag = await prisma.auftrag.findUnique({
      where: { id: params.id }
    })
    
    if (!existingAuftrag) {
      console.log('Auftrag not found:', params.id)
      return NextResponse.json(
        { error: 'Auftrag nicht gefunden' },
        { status: 404 }
      )
    }
    
    const validatedData = AuftragUpdateSchema.parse(body)
    console.log('Validated data:', validatedData)
    
    const auftrag = await prisma.auftrag.update({
      where: { id: params.id },
      data: validatedData,
      include: {
        firma: true,
        projektleiter: true,
        statusVerlauf: true
      }
    })

    // Status-Verlauf aktualisieren wenn sich der Status geändert hat
    if (existingAuftrag.status !== validatedData.status) {
      await prisma.statusVerlauf.create({
        data: {
          auftragId: auftrag.id,
          status: validatedData.status,
          kommentar: 'Status aktualisiert'
        }
      })
    }

    console.log('Auftrag updated successfully:', auftrag.titel)
    return NextResponse.json(auftrag)
  } catch (error) {
    if (error instanceof z.ZodError) {
      console.error('Validation error:', error.errors)
      return NextResponse.json(
        { error: 'Ungültige Daten', details: error.errors },
        { status: 400 }
      )
    }

    console.error('Fehler beim Aktualisieren des Auftrags:', error)
    return NextResponse.json(
      { error: 'Fehler beim Aktualisieren des Auftrags', details: error },
      { status: 500 }
    )
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    // Überprüfe ob der Auftrag existiert
    const existingAuftrag = await prisma.auftrag.findUnique({
      where: { id: params.id }
    })
    
    if (!existingAuftrag) {
      return NextResponse.json(
        { error: 'Auftrag nicht gefunden' },
        { status: 404 }
      )
    }

    await prisma.auftrag.delete({
      where: { id: params.id }
    })

    console.log('Auftrag deleted successfully:', params.id)
    return NextResponse.json({ message: 'Auftrag erfolgreich gelöscht' })
  } catch (error) {
    console.error('Fehler beim Löschen des Auftrags:', error)
    return NextResponse.json(
      { error: 'Fehler beim Löschen des Auftrags' },
      { status: 500 }
    )
  }
}


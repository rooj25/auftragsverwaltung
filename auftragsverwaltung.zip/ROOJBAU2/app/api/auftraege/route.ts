import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { z } from 'zod'

const AuftragSchema = z.object({
  titel: z.string().min(1, 'Titel ist erforderlich'),
  beschreibung: z.string().optional(),
  status: z.string().refine(val => ['NEU', 'IN_BEARBEITUNG', 'WARTEND', 'ABGESCHLOSSEN', 'STORNIERT'].includes(val), {
    message: 'Ungültiger Status'
  }).default('NEU'),
  prioritaet: z.string().refine(val => ['NIEDRIG', 'NORMAL', 'HOCH', 'KRITISCH'].includes(val), {
    message: 'Ungültige Priorität'
  }).default('NORMAL'),
  startdatum: z.string().optional(),
  geplantesEnddatum: z.string().optional(),
  geschaetzterAufwand: z.number().optional(),
  kosten: z.number().optional(),
  notizen: z.string().optional(),
  firmaId: z.string().min(1, 'Firma ist erforderlich'),
  projektleiterId: z.string().optional(),
})

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const firmaId = searchParams.get('firmaId')
    const status = searchParams.get('status')
    const prioritaet = searchParams.get('prioritaet')

    const where: any = {}
    if (firmaId) where.firmaId = firmaId
    if (status) where.status = status
    if (prioritaet) where.prioritaet = prioritaet

    const auftraege = await prisma.auftrag.findMany({
      where,
      include: {
        firma: true,
        projektleiter: true,
        statusVerlauf: {
          orderBy: {
            erstelltAm: 'desc'
          }
        }
      },
      orderBy: {
        erstelltAm: 'desc'
      }
    })

    return NextResponse.json(auftraege)
  } catch (error) {
    console.error('Fehler beim Laden der Aufträge:', error)
    return NextResponse.json(
      { error: 'Fehler beim Laden der Aufträge' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    
    const validatedData = AuftragSchema.parse(body)
    
    // Automatische Auftragsnummer generieren
    const lastAuftrag = await prisma.auftrag.findFirst({
      orderBy: { auftragsnummer: 'desc' }
    })
    
    const currentYear = new Date().getFullYear()
    let nextNumber = 1
    
    if (lastAuftrag?.auftragsnummer) {
      const match = lastAuftrag.auftragsnummer.match(/AUF-(\d{4})-(\d{3})/)
      if (match && parseInt(match[1]) === currentYear) {
        nextNumber = parseInt(match[2]) + 1
      }
    }
    
    const auftragsnummer = `AUF-${currentYear}-${nextNumber.toString().padStart(3, '0')}`
    
    // Datum-Strings zu Date-Objekten konvertieren
    const data: any = {
      ...validatedData,
      auftragsnummer,
    }
    
    if (validatedData.startdatum) {
      data.startdatum = new Date(validatedData.startdatum)
    }
    if (validatedData.geplantesEnddatum) {
      data.geplantesEnddatum = new Date(validatedData.geplantesEnddatum)
    }
    
    const auftrag = await prisma.auftrag.create({
      data,
      include: {
        firma: true,
        projektleiter: true,
        statusVerlauf: true
      }
    })

    // Ersten Status-Eintrag erstellen
    await prisma.statusVerlauf.create({
      data: {
        auftragId: auftrag.id,
        status: auftrag.status,
        kommentar: 'Auftrag erstellt'
      }
    })

    return NextResponse.json(auftrag, { status: 201 })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Ungültige Daten', details: error.errors },
        { status: 400 }
      )
    }

    console.error('Fehler beim Erstellen des Auftrags:', error)
    return NextResponse.json(
      { error: 'Fehler beim Erstellen des Auftrags' },
      { status: 500 }
    )
  }
}

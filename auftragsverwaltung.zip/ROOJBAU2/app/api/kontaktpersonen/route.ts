import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { z } from 'zod'

const TelefonnummerSchema = z.object({
  nummer: z.string().min(1, 'Telefonnummer ist erforderlich'),
  typ: z.string().optional(),
  notizen: z.string().optional(),
})

const KontaktpersonSchema = z.object({
  vorname: z.string().min(1, 'Vorname ist erforderlich'),
  nachname: z.string().min(1, 'Nachname ist erforderlich'),
  position: z.string().optional(),
  abteilung: z.string().optional(),
  etage: z.string().optional(),
  raum: z.string().optional(),
  email: z.string().email('Ungültige E-Mail-Adresse').optional().or(z.literal('').transform(() => undefined)),
  notizen: z.string().optional(),
  auftragId: z.string().min(1, 'Auftrag ist erforderlich'),
  telefonnummern: z.array(TelefonnummerSchema).optional().default([]),
}).transform((data) => {
  return {
    vorname: data.vorname,
    nachname: data.nachname,
    position: data.position || undefined,
    abteilung: data.abteilung || undefined,
    etage: data.etage || undefined,
    raum: data.raum || undefined,
    email: data.email || undefined,
    notizen: data.notizen || undefined,
    auftragId: data.auftragId,
    telefonnummern: data.telefonnummern,
  }
})

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const auftragId = searchParams.get('auftragId')

    if (auftragId) {
      // Kontaktpersonen für einen bestimmten Auftrag
      const kontaktpersonen = await prisma.kontaktperson.findMany({
        where: { auftragId },
        include: {
          telefonnummern: true,
          kommunikationen: {
            orderBy: { datum: 'desc' },
            take: 5 // Nur die letzten 5 Kommunikationen
          }
        },
        orderBy: { erstelltAm: 'desc' }
      })
      return NextResponse.json(kontaktpersonen)
    } else {
      // Alle Kontaktpersonen
      const kontaktpersonen = await prisma.kontaktperson.findMany({
        include: {
          telefonnummern: true,
          auftrag: {
            select: {
              id: true,
              titel: true,
              auftragsnummer: true
            }
          }
        },
        orderBy: { erstelltAm: 'desc' }
      })
      return NextResponse.json(kontaktpersonen)
    }
  } catch (error) {
    console.error('Fehler beim Laden der Kontaktpersonen:', error)
    return NextResponse.json(
      { error: 'Fehler beim Laden der Kontaktpersonen' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const validatedData = KontaktpersonSchema.parse(body)

    const kontaktperson = await prisma.kontaktperson.create({
      data: {
        vorname: validatedData.vorname,
        nachname: validatedData.nachname,
        position: validatedData.position,
        abteilung: validatedData.abteilung,
        etage: validatedData.etage,
        raum: validatedData.raum,
        email: validatedData.email,
        notizen: validatedData.notizen,
        auftragId: validatedData.auftragId,
        telefonnummern: {
          create: validatedData.telefonnummern.map(tel => ({
            nummer: tel.nummer,
            typ: tel.typ,
            notizen: tel.notizen,
          }))
        }
      },
      include: {
        telefonnummern: true
      }
    })

    return NextResponse.json(kontaktperson, { status: 201 })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Ungültige Daten', details: error.errors },
        { status: 400 }
      )
    }

    console.error('Fehler beim Erstellen der Kontaktperson:', error)
    return NextResponse.json(
      { error: 'Fehler beim Erstellen der Kontaktperson' },
      { status: 500 }
    )
  }
}


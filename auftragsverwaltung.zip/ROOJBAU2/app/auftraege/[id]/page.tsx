'use client'

import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { ArrowLeft, Edit } from 'lucide-react'
import Link from 'next/link'
import { getStatusColor, getStatusText, getPriorityColor, getPriorityText } from '@/lib/utils'

interface Auftrag {
  id: string
  auftragsnummer: string
  titel: string
  adresse?: string
  beschreibung?: string
  status: string
  prioritaet: string
  startdatum?: string
  geplantesEnddatum?: string
  geschaetzterAufwand?: number
  kosten?: number
  notizen?: string
  erstelltAm: string
  aktualisiertAm: string
  firma: {
    id: string
    name: string
    telefon?: string
    email?: string
  }
  projektleiter?: {
    id: string
    vorname: string
    nachname: string
    telefon?: string
    email?: string
    position?: string
  }
}

export default function AuftragDetailPage({ params }: { params: { id: string } }) {
  const { data: auftrag, isLoading, error } = useQuery({
    queryKey: ['auftrag', params.id],
    queryFn: async () => {
      const response = await fetch(`/api/auftraege/${params.id}`)
      if (!response.ok) {
        throw new Error('Auftrag nicht gefunden')
      }
      return response.json() as Promise<Auftrag>
    }
  })

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-100 p-4">
        <div className="max-w-4xl mx-auto bg-white border border-gray-300 p-6">
          <div className="animate-pulse">
            <div className="h-6 bg-gray-200 rounded mb-4 w-1/3"></div>
            <div className="space-y-3">
              <div className="h-4 bg-gray-200 rounded"></div>
              <div className="h-4 bg-gray-200 rounded w-2/3"></div>
            </div>
          </div>
        </div>
      </div>
    )
  }

  if (error || !auftrag) {
    return (
      <div className="min-h-screen bg-gray-100 p-4">
        <div className="max-w-4xl mx-auto bg-white border border-gray-300 p-6">
          <h1 className="text-xl font-bold mb-4">Auftrag nicht gefunden</h1>
          <Button asChild>
            <Link href="/auftraege">Zurück zur Auftragsliste</Link>
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Windows-Style Header */}
      <div className="bg-white border-b border-gray-300 px-4 py-3">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Button variant="outline" size="sm" asChild className="border-gray-400">
              <Link href="/auftraege">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Zurück
              </Link>
            </Button>
            <div>
              <h1 className="text-lg font-semibold">Auftragsinformationen</h1>
              <p className="text-sm text-gray-600">{auftrag.auftragsnummer}</p>
            </div>
            <div className="flex space-x-2">
              <Badge className={getStatusColor(auftrag.status)} variant="outline">
                {getStatusText(auftrag.status)}
              </Badge>
              <Badge className={getPriorityColor(auftrag.prioritaet)} variant="outline">
                {getPriorityText(auftrag.prioritaet)}
              </Badge>
            </div>
          </div>
          <Button asChild size="sm" className="border-gray-400">
            <Link href={`/auftraege/${auftrag.id}/bearbeiten`}>
              <Edit className="mr-2 h-4 w-4" />
              Bearbeiten
            </Link>
          </Button>
        </div>
      </div>

      {/* Windows-Style Form */}
      <div className="p-4">
        <div className="max-w-4xl mx-auto">
          <div className="bg-white border border-gray-300 p-6">
            
            {/* Auftragsinformationen */}
            <fieldset className="border border-gray-400 p-4 mb-6">
              <legend className="px-2 text-sm font-medium bg-white">Auftragsinformationen</legend>
              
              <div className="grid gap-4 md:grid-cols-2 mt-4">
                <div className="md:col-span-2">
                  <Label className="text-sm font-medium">Auftragstitel:</Label>
                  <Input
                    value={auftrag.titel}
                    readOnly
                    className="mt-1 border-gray-400 bg-gray-50"
                  />
                </div>

                {auftrag.adresse && (
                  <div className="md:col-span-2">
                    <Label className="text-sm font-medium">Adresse:</Label>
                    <Input
                      value={auftrag.adresse}
                      readOnly
                      className="mt-1 border-gray-400 bg-gray-50"
                    />
                  </div>
                )}

                <div>
                  <Label className="text-sm font-medium">Status:</Label>
                  <Input
                    value={getStatusText(auftrag.status)}
                    readOnly
                    className="mt-1 border-gray-400 bg-gray-50"
                  />
                </div>

                <div>
                  <Label className="text-sm font-medium">Priorität:</Label>
                  <Input
                    value={getPriorityText(auftrag.prioritaet)}
                    readOnly
                    className="mt-1 border-gray-400 bg-gray-50"
                  />
                </div>

                <div className="md:col-span-2">
                  <Label className="text-sm font-medium">Kontakt Personen:</Label>
                  <Textarea
                    value={auftrag.beschreibung || ''}
                    readOnly
                    placeholder="Notizen zu Kontaktpersonen..."
                    className="mt-1 border-gray-400 bg-gray-50"
                    rows={3}
                  />
                </div>
              </div>
            </fieldset>

            {/* Termine & Budget */}
            <fieldset className="border border-gray-400 p-4 mb-6">
              <legend className="px-2 text-sm font-medium bg-white">Termine & Budget</legend>
              
              <div className="grid gap-4 md:grid-cols-2 mt-4">
                {auftrag.startdatum && (
                  <div>
                    <Label className="text-sm font-medium">Startdatum:</Label>
                    <Input
                      value={auftrag.startdatum.split('T')[0]}
                      readOnly
                      type="date"
                      className="mt-1 border-gray-400 bg-gray-50"
                    />
                  </div>
                )}

                {auftrag.geplantesEnddatum && (
                  <div>
                    <Label className="text-sm font-medium">Geplantes Enddatum:</Label>
                    <Input
                      value={auftrag.geplantesEnddatum.split('T')[0]}
                      readOnly
                      type="date"
                      className="mt-1 border-gray-400 bg-gray-50"
                    />
                  </div>
                )}

                {auftrag.geschaetzterAufwand && (
                  <div>
                    <Label className="text-sm font-medium">Aufwand (Std.):</Label>
                    <Input
                      value={auftrag.geschaetzterAufwand.toString()}
                      readOnly
                      className="mt-1 border-gray-400 bg-gray-50"
                    />
                  </div>
                )}

                {auftrag.kosten && (
                  <div>
                    <Label className="text-sm font-medium">Kosten (€):</Label>
                    <Input
                      value={auftrag.kosten.toString()}
                      readOnly
                      className="mt-1 border-gray-400 bg-gray-50"
                    />
                  </div>
                )}

                {auftrag.notizen && (
                  <div className="md:col-span-2">
                    <Label className="text-sm font-medium">Notizen:</Label>
                    <Textarea
                      value={auftrag.notizen}
                      readOnly
                      className="mt-1 border-gray-400 bg-gray-50"
                      rows={3}
                    />
                  </div>
                )}
              </div>
            </fieldset>

            {/* Zuordnung */}
            <fieldset className="border border-gray-400 p-4">
              <legend className="px-2 text-sm font-medium bg-white">Zuordnung</legend>
              
              <div className="grid gap-4 md:grid-cols-2 mt-4">
                <div>
                  <Label className="text-sm font-medium">Firma:</Label>
                  <Input
                    value={auftrag.firma.name}
                    readOnly
                    className="mt-1 border-gray-400 bg-gray-50"
                  />
                  {auftrag.firma.telefon && (
                    <p className="text-xs text-gray-600 mt-1">Tel: {auftrag.firma.telefon}</p>
                  )}
                  {auftrag.firma.email && (
                    <p className="text-xs text-gray-600">E-Mail: {auftrag.firma.email}</p>
                  )}
                </div>

                {auftrag.projektleiter && (
                  <div>
                    <Label className="text-sm font-medium">Projektleiter:</Label>
                    <Input
                      value={`${auftrag.projektleiter.vorname} ${auftrag.projektleiter.nachname}`}
                      readOnly
                      className="mt-1 border-gray-400 bg-gray-50"
                    />
                    {auftrag.projektleiter.position && (
                      <p className="text-xs text-gray-600 mt-1">{auftrag.projektleiter.position}</p>
                    )}
                    {auftrag.projektleiter.telefon && (
                      <p className="text-xs text-gray-600">Tel: {auftrag.projektleiter.telefon}</p>
                    )}
                    {auftrag.projektleiter.email && (
                      <p className="text-xs text-gray-600">E-Mail: {auftrag.projektleiter.email}</p>
                    )}
                  </div>
                )}
              </div>
            </fieldset>
          </div>
        </div>
      </div>
    </div>
  )
}
'use client'

import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { FileText, Plus, Search, Calendar, Building2, User, Grid3X3, List, Table } from 'lucide-react'
import Link from 'next/link'
import { getStatusColor, getStatusText, getPriorityColor, getPriorityText, formatDate, formatCurrency } from '@/lib/utils'

interface Auftrag {
  id: string
  auftragsnummer: string
  titel: string
  beschreibung?: string
  status: string
  prioritaet: string
  startdatum?: string
  geplantesEnddatum?: string
  kosten?: number
  firma: {
    id: string
    name: string
  }
  projektleiter?: {
    id: string
    vorname: string
    nachname: string
  }
  erstelltAm: string
}

export default function AuftraegePage() {
  const [searchTerm, setSearchTerm] = useState('')
  const [statusFilter, setStatusFilter] = useState('')
  const [viewMode, setViewMode] = useState<'cards' | 'list' | 'table'>('cards')

  const { data: auftraege, isLoading, error } = useQuery({
    queryKey: ['auftraege'],
    queryFn: async () => {
      const response = await fetch('/api/auftraege')
      if (!response.ok) {
        throw new Error('Fehler beim Laden der Aufträge')
      }
      return response.json() as Promise<Auftrag[]>
    }
  })

  const filteredAuftraege = auftraege?.filter(auftrag => {
    const matchesSearch = auftrag.titel.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         auftrag.auftragsnummer.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         auftrag.firma.name.toLowerCase().includes(searchTerm.toLowerCase())
    
    const matchesStatus = !statusFilter || auftrag.status === statusFilter
    
    return matchesSearch && matchesStatus
  }) || []

  if (isLoading) {
    return (
      <div className="min-h-screen">
        <div className="spacing-4 lg:spacing-6">
          <div className="text-center space-y-4">
            <h1 className="headline-large font-bold text-gray-900 dark:text-white">Aufträge</h1>
            <div className="fintech-kpi-card spacing-4 max-w-md mx-auto">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-400 mx-auto mb-4"></div>
              <p className="body-medium text-gray-400">Aufträge werden geladen...</p>
            </div>
          </div>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="min-h-screen">
        <div className="spacing-4 lg:spacing-6">
          <div className="text-center space-y-4">
            <h1 className="headline-large font-bold text-gray-900 dark:text-white">Aufträge</h1>
            <div className="fintech-card spacing-4 max-w-md mx-auto">
              <p className="body-medium text-red-400">Fehler beim Laden der Aufträge. Bitte versuchen Sie es erneut.</p>
            </div>
          </div>
        </div>
      </div>
    )
  }

  const statusOptions = [
    { value: '', label: 'Alle Status' },
    { value: 'NEU', label: 'Neu' },
    { value: 'IN_BEARBEITUNG', label: 'In Bearbeitung' },
    { value: 'WARTEND', label: 'Wartend' },
    { value: 'ABGESCHLOSSEN', label: 'Abgeschlossen' },
    { value: 'STORNIERT', label: 'Storniert' },
  ]

  return (
    <div className="min-h-screen">
      {/* Hero Section - Material 3 */}
      <div className="spacing-4 lg:spacing-6">
        <div className="text-center lg:text-left space-y-4">
          <div className="space-y-2">
            <h1 className="display-medium lg:display-large font-bold bg-gradient-to-r from-purple-400 via-blue-400 to-cyan-400 bg-clip-text text-transparent">
              Aufträge
            </h1>
            <p className="body-large text-gray-600 dark:text-gray-400 max-w-2xl">
              Verwalten Sie alle Ihre Aufträge und deren Status effizient
            </p>
          </div>
          
          {/* Primary CTA + View Controls */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start items-center">
            <Link href="/auftraege/neu">
              <div className="fintech-button-primary micro-slide-up neon-glow-purple">
                <Plus className="mr-2 h-4 w-4" />
                Neuer Auftrag
              </div>
            </Link>
            
            {/* View Mode Controls - Desktop Only */}
            <div className="desktop-only flex border border-gray-300 dark:border-gray-700 rounded-2xl overflow-hidden">
              <button
                onClick={() => setViewMode('cards')}
                className={`px-4 py-2 text-xs transition-all ${viewMode === 'cards' ? 'fintech-button-primary' : 'ios-button-secondary'}`}
              >
                <Grid3X3 className="h-3 w-3" />
              </button>
              <button
                onClick={() => setViewMode('list')}
                className={`px-4 py-2 text-xs transition-all border-l border-gray-300 dark:border-gray-700 ${viewMode === 'list' ? 'fintech-button-primary' : 'ios-button-secondary'}`}
              >
                <List className="h-3 w-3" />
              </button>
              <button
                onClick={() => setViewMode('table')}
                className={`px-4 py-2 text-xs transition-all border-l border-gray-300 dark:border-gray-700 ${viewMode === 'table' ? 'fintech-button-primary' : 'ios-button-secondary'}`}
              >
                <Table className="h-3 w-3" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Sticky Search + Filter Bar - iOS Style */}
      <div className="sticky top-0 z-30 spacing-2">
        <div className="ios-search-bar mx-4 lg:mx-6">
          <div className="flex flex-col sm:flex-row gap-3 sm:items-center">
            <div className="flex items-center space-x-3 flex-1">
              <Search className="h-5 w-5 text-gray-400 dark:text-gray-500" />
              <input
                placeholder="Aufträge durchsuchen..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="flex-1 bg-transparent border-none outline-none text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400"
              />
            </div>
            
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="ios-button-secondary px-3 py-2 text-xs border-none bg-transparent focus:outline-none"
            >
              {statusOptions.map(option => (
                <option key={option.value} value={option.value} className="bg-white dark:bg-gray-900 text-gray-900 dark:text-white">
                  {option.label}
                </option>
              ))}
            </select>
            
            <div className="ios-button-secondary px-3 py-2 text-xs">
              {filteredAuftraege.length} / {auftraege?.length || 0}
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="spacing-4 lg:spacing-6">
        {filteredAuftraege.length === 0 ? (
          <div className="text-center">
            <div className="fintech-card spacing-4 max-w-md mx-auto">
              <div className="fintech-kpi-card p-4 mx-auto w-fit mb-4 neon-glow-purple">
                <FileText className="h-12 w-12 text-purple-400" />
              </div>
              <h3 className="title-large font-bold text-white mb-2">Keine Aufträge gefunden</h3>
              <p className="body-medium text-gray-400 mb-6">
                {searchTerm || statusFilter ? 'Keine Aufträge entsprechen Ihren Filterkriterien.' : 'Sie haben noch keine Aufträge erstellt.'}
              </p>
              <Link href="/auftraege/neu">
                <div className="fintech-button-primary micro-bounce">
                  <Plus className="mr-2 h-4 w-4" />
                  Ersten Auftrag erstellen
                </div>
              </Link>
            </div>
          </div>
        ) : (
          <>
            {/* Mobile: iOS Cards */}
            <div className="mobile-only space-y-4">
              {filteredAuftraege.map((auftrag) => (
                <div key={auftrag.id} className="ios-card spacing-3 micro-slide-up">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1 min-w-0">
                      <h3 className="title-large font-bold text-gray-900 dark:text-white truncate">{auftrag.titel}</h3>
                      <p className="body-small text-gray-600 dark:text-gray-400 font-mono mt-1">{auftrag.auftragsnummer}</p>
                    </div>
                    <Badge className={getStatusColor(auftrag.status)} variant="outline">
                      {getStatusText(auftrag.status)}
                    </Badge>
                  </div>
                  
                  <div className="space-y-2 mb-4">
                    <div className="flex items-center space-x-2">
                      <div className="fintech-kpi-card p-1">
                        <Building2 className="h-3 w-3 text-cyan-400" />
                      </div>
                      <span className="body-small text-gray-600 dark:text-gray-400">{auftrag.firma.name}</span>
                    </div>
                    {auftrag.projektleiter && (
                      <div className="flex items-center space-x-2">
                        <div className="fintech-kpi-card p-1">
                          <User className="h-3 w-3 text-purple-400" />
                        </div>
                        <span className="body-small text-gray-600 dark:text-gray-400">
                          {auftrag.projektleiter.vorname} {auftrag.projektleiter.nachname}
                        </span>
                      </div>
                    )}
                    {auftrag.geplantesEnddatum && (
                      <div className="flex items-center space-x-2">
                        <div className="fintech-kpi-card p-1">
                          <Calendar className="h-3 w-3 text-orange-400" />
                        </div>
                        <span className="body-small text-gray-600 dark:text-gray-400">
                          {formatDate(auftrag.geplantesEnddatum)}
                        </span>
                      </div>
                    )}
                  </div>
                  
                  <div className="grid grid-cols-2 gap-2 pt-3 border-t border-gray-200 dark:border-gray-700">
                    <Link href={`/auftraege/${auftrag.id}`}>
                      <div className="ios-button-secondary text-center py-3 text-xs micro-bounce">
                        Details
                      </div>
                    </Link>
                    <Link href={`/auftraege/${auftrag.id}/bearbeiten`}>
                      <div className="ios-button-secondary text-center py-3 text-xs micro-bounce">
                        Bearbeiten
                      </div>
                    </Link>
                  </div>
                </div>
              ))}
            </div>

            {/* Desktop: Different View Modes */}
            <div className="desktop-only">
              {viewMode === 'cards' && (
                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                  {filteredAuftraege.map((auftrag) => (
                    <div key={auftrag.id} className="m3-card-elevated spacing-3 micro-slide-up">
                      <div className="flex items-start justify-between mb-4">
                        <div className="space-y-1">
                          <h3 className="title-medium font-bold text-gray-900 dark:text-white">{auftrag.titel}</h3>
                          <p className="body-small text-gray-600 dark:text-gray-400 font-mono">{auftrag.auftragsnummer}</p>
                        </div>
                        <Badge className={getStatusColor(auftrag.status)} variant="outline">
                          {getStatusText(auftrag.status)}
                        </Badge>
                      </div>
                      
                      <div className="space-y-3 mb-4">
                        <div className="flex items-center space-x-2">
                          <div className="fintech-kpi-card p-2">
                            <Building2 className="h-4 w-4 text-cyan-400" />
                          </div>
                          <span className="body-medium text-gray-700 dark:text-gray-300">{auftrag.firma.name}</span>
                        </div>
                        {auftrag.projektleiter && (
                          <div className="flex items-center space-x-2">
                            <div className="fintech-kpi-card p-2">
                              <User className="h-4 w-4 text-purple-400" />
                            </div>
                            <span className="body-medium text-gray-700 dark:text-gray-300">
                              {auftrag.projektleiter.vorname} {auftrag.projektleiter.nachname}
                            </span>
                          </div>
                        )}
                        {auftrag.geplantesEnddatum && (
                          <div className="flex items-center space-x-2">
                            <div className="fintech-kpi-card p-2">
                              <Calendar className="h-4 w-4 text-orange-400" />
                            </div>
                            <span className="body-small text-gray-500 dark:text-gray-400">
                              Bis: {formatDate(auftrag.geplantesEnddatum)}
                            </span>
                          </div>
                        )}
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <Link href={`/auftraege/${auftrag.id}`}>
                          <div className="ios-button-secondary text-center py-3 text-xs micro-bounce">
                            Details
                          </div>
                        </Link>
                        <Link href={`/auftraege/${auftrag.id}/bearbeiten`}>
                          <div className="ios-button-secondary text-center py-3 text-xs micro-bounce">
                            Bearbeiten
                          </div>
                        </Link>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {viewMode === 'list' && (
                <div className="fintech-card spacing-4">
                  <div className="space-y-3">
                    {filteredAuftraege.map((auftrag) => (
                      <div key={auftrag.id} className="flex items-center justify-between p-4 bg-white/5 rounded-xl hover:bg-white/10 transition-all duration-300 micro-bounce">
                        <div className="flex-1 min-w-0 mr-4">
                          <div className="flex items-center space-x-2 mb-2">
                            <h4 className="title-medium font-bold text-white truncate">{auftrag.titel}</h4>
                            <Badge className={getStatusColor(auftrag.status)} variant="outline">
                              {getStatusText(auftrag.status)}
                            </Badge>
                            <Badge className={getPriorityColor(auftrag.prioritaet)} variant="outline">
                              {getPriorityText(auftrag.prioritaet)}
                            </Badge>
                          </div>
                          <p className="body-small text-gray-400 font-mono mb-2">{auftrag.auftragsnummer}</p>
                          <div className="flex flex-wrap gap-x-4 text-xs text-gray-400">
                            <div className="flex items-center space-x-1">
                              <Building2 className="h-3 w-3 text-cyan-400" />
                              <span>{auftrag.firma.name}</span>
                            </div>
                            {auftrag.projektleiter && (
                              <div className="flex items-center space-x-1">
                                <User className="h-3 w-3 text-purple-400" />
                                <span>{auftrag.projektleiter.vorname} {auftrag.projektleiter.nachname}</span>
                              </div>
                            )}
                            {auftrag.geplantesEnddatum && (
                              <div className="flex items-center space-x-1">
                                <Calendar className="h-3 w-3 text-orange-400" />
                                <span>{formatDate(auftrag.geplantesEnddatum)}</span>
                              </div>
                            )}
                          </div>
                        </div>
                        <div className="flex space-x-2">
                          <Link href={`/auftraege/${auftrag.id}`}>
                            <div className="ios-button-secondary px-4 py-2 text-xs micro-bounce">Details</div>
                          </Link>
                          <Link href={`/auftraege/${auftrag.id}/bearbeiten`}>
                            <div className="ios-button-secondary px-4 py-2 text-xs micro-bounce">Bearbeiten</div>
                          </Link>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {viewMode === 'table' && (
                <div className="m3-card-elevated spacing-4">
                  {/* Table Header */}
                  <div className="grid grid-cols-12 gap-4 pb-3 border-b border-gray-200 dark:border-gray-700">
                    <div className="col-span-2">
                      <span className="label-medium text-gray-600 dark:text-gray-400 uppercase tracking-widest">Nr.</span>
                    </div>
                    <div className="col-span-3">
                      <span className="label-medium text-gray-600 dark:text-gray-400 uppercase tracking-widest">Titel</span>
                    </div>
                    <div className="col-span-2">
                      <span className="label-medium text-gray-600 dark:text-gray-400 uppercase tracking-widest">Firma</span>
                    </div>
                    <div className="col-span-2">
                      <span className="label-medium text-gray-600 dark:text-gray-400 uppercase tracking-widest">Status</span>
                    </div>
                    <div className="col-span-1">
                      <span className="label-medium text-gray-600 dark:text-gray-400 uppercase tracking-widest">Prio</span>
                    </div>
                    <div className="col-span-2">
                      <span className="label-medium text-gray-600 dark:text-gray-400 uppercase tracking-widest">Aktionen</span>
                    </div>
                  </div>

                  {/* Table Rows */}
                  <div className="space-y-2 mt-4">
                    {filteredAuftraege.map((auftrag) => (
                      <div key={auftrag.id} className="grid grid-cols-12 gap-4 items-center py-4 px-3 rounded-xl hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-all duration-300 micro-bounce">
                        <div className="col-span-2">
                          <span className="body-small font-mono text-gray-700 dark:text-gray-300">{auftrag.auftragsnummer}</span>
                        </div>
                        <div className="col-span-3">
                          <span className="title-medium font-bold text-gray-900 dark:text-white truncate">{auftrag.titel}</span>
                        </div>
                        <div className="col-span-2">
                          <span className="body-medium text-gray-700 dark:text-gray-300 truncate">{auftrag.firma.name}</span>
                        </div>
                        <div className="col-span-2">
                          <Badge className={getStatusColor(auftrag.status)} variant="outline">
                            {getStatusText(auftrag.status)}
                          </Badge>
                        </div>
                        <div className="col-span-1">
                          <Badge className={getPriorityColor(auftrag.prioritaet)} variant="outline">
                            {getPriorityText(auftrag.prioritaet)}
                          </Badge>
                        </div>
                        <div className="col-span-2">
                          <div className="flex space-x-1">
                            <Link href={`/auftraege/${auftrag.id}`}>
                              <div className="ios-button-secondary px-2 py-1 text-xs micro-bounce">Details</div>
                            </Link>
                            <Link href={`/auftraege/${auftrag.id}/bearbeiten`}>
                              <div className="m3-button-outlined px-2 py-1 text-xs micro-bounce">Bearbeiten</div>
                            </Link>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  )
}
'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Toast } from '@/components/ui/toast'
import { ArrowLeft, Save } from 'lucide-react'
import Link from 'next/link'

interface Firma {
  id: string
  name: string
  projektleiter: {
    id: string
    vorname: string
    nachname: string
  }[]
}

export default function NeuerAuftragPage() {
  const router = useRouter()
  const queryClient = useQueryClient()
  const [isLoading, setIsLoading] = useState(false)
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null)
  const [formData, setFormData] = useState({
    titel: '',
    adresse: '',
    beschreibung: '',
    status: 'NEU',
    prioritaet: 'NORMAL',
    startdatum: '',
    geplantesEnddatum: '',
    geschaetzterAufwand: '',
    kosten: '',
    notizen: '',
    firmaId: '',
    projektleiterId: ''
  })

  const { data: firmen } = useQuery({
    queryKey: ['firmen'],
    queryFn: async () => {
      const response = await fetch('/api/firmen')
      if (!response.ok) {
        throw new Error('Firmen konnten nicht geladen werden')
      }
      return response.json() as Promise<Firma[]>
    }
  })

  const selectedFirma = firmen?.find(f => f.id === formData.firmaId)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      const submitData = {
        titel: formData.titel.trim(),
        adresse: formData.adresse.trim() || undefined,
        beschreibung: formData.beschreibung.trim() || undefined,
        status: formData.status,
        prioritaet: formData.prioritaet,
        startdatum: formData.startdatum || undefined,
        geplantesEnddatum: formData.geplantesEnddatum || undefined,
        geschaetzterAufwand: formData.geschaetzterAufwand ? parseFloat(formData.geschaetzterAufwand) : undefined,
        kosten: formData.kosten ? parseFloat(formData.kosten) : undefined,
        notizen: formData.notizen.trim() || undefined,
        firmaId: formData.firmaId,
        projektleiterId: formData.projektleiterId || undefined,
      }

      const response = await fetch('/api/auftraege', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(submitData),
      })

      if (!response.ok) {
        throw new Error('Fehler beim Erstellen')
      }

      const newAuftrag = await response.json()
      await queryClient.invalidateQueries({ queryKey: ['auftraege'] })
      setToast({ message: 'Auftrag erfolgreich erstellt!', type: 'success' })
      
      setTimeout(() => {
        router.push(`/auftraege/${newAuftrag.id}`)
      }, 1500)
    } catch (error) {
      setToast({ 
        message: `Fehler beim Erstellen: ${error instanceof Error ? error.message : 'Unbekannter Fehler'}`, 
        type: 'error' 
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormData(prev => ({ ...prev, [name]: value }))
  }

  const statusOptions = [
    { value: 'NEU', label: 'Neu' },
    { value: 'IN_BEARBEITUNG', label: 'In Bearbeitung' },
    { value: 'WARTEND', label: 'Wartend' },
    { value: 'ABGESCHLOSSEN', label: 'Abgeschlossen' },
    { value: 'STORNIERT', label: 'Storniert' },
  ]

  const priorityOptions = [
    { value: 'NIEDRIG', label: 'Niedrig' },
    { value: 'NORMAL', label: 'Normal' },
    { value: 'HOCH', label: 'Hoch' },
    { value: 'KRITISCH', label: 'Kritisch' },
  ]

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Toast */}
      {toast && (
        <Toast 
          message={toast.message} 
          type={toast.type} 
          onClose={() => setToast(null)} 
        />
      )}

      {/* Windows-Style Header */}
      <div className="bg-white border-b border-gray-300 px-4 py-3">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Button variant="outline" size="sm" asChild className="border-gray-400">
              <Link href="/auftraege">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Zurück
              </Link>
            </Button>
            <div>
              <h1 className="text-lg font-semibold">Neuer Auftrag</h1>
              <p className="text-sm text-gray-600">Auftrag erstellen</p>
            </div>
          </div>
        </div>
      </div>

      {/* Windows-Style Form */}
      <div className="p-4">
        <div className="max-w-4xl mx-auto">
          <form onSubmit={handleSubmit}>
            <div className="bg-white border border-gray-300 p-6">
              
              {/* Auftragsinformationen */}
              <fieldset className="border border-gray-400 p-4 mb-6">
                <legend className="px-2 text-sm font-medium bg-white">Auftragsinformationen</legend>
                
                <div className="grid gap-4 md:grid-cols-2 mt-4">
                  <div className="md:col-span-2">
                    <Label className="text-sm font-medium">Auftragstitel: *</Label>
                    <Input
                      name="titel"
                      value={formData.titel}
                      onChange={handleChange}
                      placeholder="z.B. Website Redesign"
                      className="mt-1 border-gray-400"
                      required
                    />
                  </div>

                  <div className="md:col-span-2">
                    <Label className="text-sm font-medium">Adresse:</Label>
                    <Input
                      name="adresse"
                      value={formData.adresse}
                      onChange={handleChange}
                      placeholder="z.B. Musterstraße 123, 12345 Musterstadt"
                      className="mt-1 border-gray-400"
                    />
                  </div>

                  <div>
                    <Label className="text-sm font-medium">Status:</Label>
                    <select
                      name="status"
                      value={formData.status}
                      onChange={handleChange}
                      className="mt-1 w-full px-3 py-2 border border-gray-400 rounded-md bg-white"
                    >
                      {statusOptions.map(option => (
                        <option key={option.value} value={option.value}>
                          {option.label}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <Label className="text-sm font-medium">Priorität:</Label>
                    <select
                      name="prioritaet"
                      value={formData.prioritaet}
                      onChange={handleChange}
                      className="mt-1 w-full px-3 py-2 border border-gray-400 rounded-md bg-white"
                    >
                      {priorityOptions.map(option => (
                        <option key={option.value} value={option.value}>
                          {option.label}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="md:col-span-2">
                    <Label className="text-sm font-medium">Kontakt Personen:</Label>
                    <Textarea
                      name="beschreibung"
                      value={formData.beschreibung}
                      onChange={handleChange}
                      placeholder="Notizen zu Kontaktpersonen..."
                      className="mt-1 border-gray-400"
                      rows={3}
                    />
                  </div>
                </div>
              </fieldset>

              {/* Termine & Budget */}
              <fieldset className="border border-gray-400 p-4 mb-6">
                <legend className="px-2 text-sm font-medium bg-white">Termine & Budget</legend>
                
                <div className="grid gap-4 md:grid-cols-2 mt-4">
                  <div>
                    <Label className="text-sm font-medium">Startdatum:</Label>
                    <Input
                      name="startdatum"
                      value={formData.startdatum}
                      onChange={handleChange}
                      type="date"
                      className="mt-1 border-gray-400"
                    />
                  </div>

                  <div>
                    <Label className="text-sm font-medium">Geplantes Enddatum:</Label>
                    <Input
                      name="geplantesEnddatum"
                      value={formData.geplantesEnddatum}
                      onChange={handleChange}
                      type="date"
                      className="mt-1 border-gray-400"
                    />
                  </div>

                  <div>
                    <Label className="text-sm font-medium">Aufwand (Std.):</Label>
                    <Input
                      name="geschaetzterAufwand"
                      value={formData.geschaetzterAufwand}
                      onChange={handleChange}
                      placeholder="z.B. 40"
                      type="number"
                      min="0"
                      step="0.5"
                      className="mt-1 border-gray-400"
                    />
                  </div>

                  <div>
                    <Label className="text-sm font-medium">Kosten (€):</Label>
                    <Input
                      name="kosten"
                      value={formData.kosten}
                      onChange={handleChange}
                      placeholder="z.B. 5000"
                      type="number"
                      min="0"
                      step="0.01"
                      className="mt-1 border-gray-400"
                    />
                  </div>

                  <div className="md:col-span-2">
                    <Label className="text-sm font-medium">Notizen:</Label>
                    <Textarea
                      name="notizen"
                      value={formData.notizen}
                      onChange={handleChange}
                      placeholder="Zusätzliche Informationen zum Auftrag..."
                      className="mt-1 border-gray-400"
                      rows={3}
                    />
                  </div>
                </div>
              </fieldset>

              {/* Zuordnung */}
              <fieldset className="border border-gray-400 p-4 mb-6">
                <legend className="px-2 text-sm font-medium bg-white">Zuordnung</legend>
                
                <div className="grid gap-4 md:grid-cols-2 mt-4">
                  <div>
                    <Label className="text-sm font-medium">Firma: *</Label>
                    <select
                      name="firmaId"
                      value={formData.firmaId}
                      onChange={handleChange}
                      className="mt-1 w-full px-3 py-2 border border-gray-400 rounded-md bg-white"
                      required
                    >
                      <option value="">Firma auswählen...</option>
                      {firmen?.map((firma) => (
                        <option key={firma.id} value={firma.id}>
                          {firma.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  {selectedFirma && selectedFirma.projektleiter.length > 0 && (
                    <div>
                      <Label className="text-sm font-medium">Projektleiter:</Label>
                      <select
                        name="projektleiterId"
                        value={formData.projektleiterId}
                        onChange={handleChange}
                        className="mt-1 w-full px-3 py-2 border border-gray-400 rounded-md bg-white"
                      >
                        <option value="">Projektleiter auswählen...</option>
                        {selectedFirma.projektleiter.map((projektleiter) => (
                          <option key={projektleiter.id} value={projektleiter.id}>
                            {projektleiter.vorname} {projektleiter.nachname}
                          </option>
                        ))}
                      </select>
                    </div>
                  )}
                </div>

                {selectedFirma && selectedFirma.projektleiter.length === 0 && (
                  <div className="mt-4 p-3 bg-yellow-50 border border-yellow-300 rounded">
                    <p className="text-sm text-yellow-800">
                      <strong>Hinweis:</strong> Diese Firma hat noch keine Projektleiter.
                      Sie können später einen Projektleiter zuordnen oder{' '}
                      <Link href={`/firmen/${selectedFirma.id}/bearbeiten`} className="text-blue-600 hover:text-blue-500 underline">
                        hier einen hinzufügen
                      </Link>.
                    </p>
                  </div>
                )}
              </fieldset>

              {/* Buttons */}
              <div className="flex justify-end space-x-3 pt-4 border-t border-gray-300">
                <Button type="button" variant="outline" asChild className="border-gray-400">
                  <Link href="/auftraege">Abbrechen</Link>
                </Button>
                <Button
                  type="submit"
                  disabled={isLoading || !formData.titel.trim() || !formData.firmaId}
                  className="border-gray-400"
                >
                  {isLoading ? (
                    <>
                      <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
                      Erstelle...
                    </>
                  ) : (
                    <>
                      <Save className="mr-2 h-4 w-4" />
                      Auftrag erstellen
                    </>
                  )}
                </Button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  )
}
'use client'

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'

export default function HomePage() {
  const router = useRouter()
  
  useEffect(() => {
    // Redirect zur Firmen-Seite als neue Startseite
    router.replace('/firmen')
  }, [router])

  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="fintech-kpi-card spacing-4 text-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-400 mx-auto mb-4"></div>
        <p className="body-medium text-gray-400">Weiterleitung...</p>
      </div>
    </div>
  )
}

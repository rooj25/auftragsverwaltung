'use client'

import { useState, useEffect } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Toast } from '@/components/ui/toast'
import { ArrowLeft, Save, User } from 'lucide-react'
import Link from 'next/link'

interface Firma {
  id: string
  name: string
}

export default function NeuerProjektleiterPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const queryClient = useQueryClient()
  
  const firmaId = searchParams.get('firmaId')
  const firmaName = searchParams.get('firmaName')
  
  const [isLoading, setIsLoading] = useState(false)
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null)
  const [formData, setFormData] = useState({
    vorname: '',
    nachname: '',
    telefon: '',
    email: '',
    position: '',
    notizen: '',
    firmaId: firmaId || ''
  })

  // Firmen für Dropdown laden
  const { data: firmen } = useQuery({
    queryKey: ['firmen'],
    queryFn: async () => {
      const response = await fetch('/api/firmen')
      if (!response.ok) throw new Error('Fehler beim Laden der Firmen')
      return response.json() as Promise<Firma[]>
    }
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      const response = await fetch('/api/projektleiter', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          vorname: formData.vorname.trim(),
          nachname: formData.nachname.trim(),
          telefon: formData.telefon.trim() || undefined,
          email: formData.email.trim() || undefined,
          position: formData.position.trim() || undefined,
          notizen: formData.notizen.trim() || undefined,
          firmaId: formData.firmaId,
        }),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || 'Fehler beim Erstellen des Projektleiters')
      }

      const newProjektleiter = await response.json()
      
      // Invalidate queries to refresh data
      queryClient.invalidateQueries({ queryKey: ['firma', formData.firmaId] })
      queryClient.invalidateQueries({ queryKey: ['firmen'] })
      queryClient.invalidateQueries({ queryKey: ['projektleiter'] })
      
      // Success message
      setToast({ message: 'Projektleiter wurde erfolgreich erstellt!', type: 'success' })
      
      // Navigate back after a short delay
      setTimeout(() => {
        if (firmaId) {
          router.push(`/firmen/${firmaId}`)
        } else {
          router.push('/projektleiter')
        }
      }, 2000)
      
    } catch (error) {
      console.error('Fehler beim Erstellen des Projektleiters:', error)
      setToast({ 
        message: `Fehler: ${error instanceof Error ? error.message : 'Unbekannter Fehler'}`, 
        type: 'error' 
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormData(prev => ({ ...prev, [name]: value }))
  }

  const backUrl = firmaId ? `/firmen/${firmaId}` : '/projektleiter'
  const backText = firmaName ? `Zurück zu ${firmaName}` : 'Zurück zu Projektleiter'

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gradient-to-br dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 transition-colors duration-300 p-6">
      {/* Toast */}
      {toast && (
        <Toast 
          message={toast.message} 
          type={toast.type} 
          onClose={() => setToast(null)} 
        />
      )}

      {/* Header */}
      <div className="flex items-center space-x-4 mb-8">
        <Button variant="ghost" size="sm" asChild className="text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800">
          <Link href={backUrl}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            {backText}
          </Link>
        </Button>
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
            Neuer Projektleiter
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            {firmaName ? `Projektleiter für ${firmaName} hinzufügen` : 'Einen neuen Projektleiter erstellen'}
          </p>
        </div>
      </div>

      {/* Formular */}
      <div className="max-w-2xl mx-auto">
        <form onSubmit={handleSubmit}>
          <Card className="dark-card-modern">
            <CardHeader>
              <CardTitle className="flex items-center text-xl text-gray-900 dark:text-white">
                <div className="fintech-kpi-card p-2 neon-glow-blue mr-3">
                  <User className="h-5 w-5 text-white" />
                </div>
                Projektleiter-Informationen
              </CardTitle>
              <CardDescription className="text-gray-600 dark:text-gray-400">
                Geben Sie die Informationen des neuen Projektleiters ein
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Firma auswählen */}
              {!firmaId && (
                <div className="space-y-2">
                  <Label htmlFor="firmaId" className="text-gray-700 dark:text-gray-300">Firma *</Label>
                  <select
                    id="firmaId"
                    name="firmaId"
                    value={formData.firmaId}
                    onChange={handleChange}
                    className="w-full px-3 py-2 border-2 rounded-xl bg-white dark:bg-gray-800 dark:border-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary"
                    required
                  >
                    <option value="">Firma auswählen...</option>
                    {firmen?.map((firma) => (
                      <option key={firma.id} value={firma.id} className="bg-white dark:bg-gray-900 text-gray-900 dark:text-white">
                        {firma.name}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="vorname" className="text-gray-700 dark:text-gray-300">Vorname *</Label>
                  <Input
                    id="vorname"
                    name="vorname"
                    value={formData.vorname}
                    onChange={handleChange}
                    placeholder="z.B. Max"
                    className="rounded-xl border-2 bg-white dark:bg-gray-800 dark:border-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-primary focus:border-primary"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="nachname" className="text-gray-700 dark:text-gray-300">Nachname *</Label>
                  <Input
                    id="nachname"
                    name="nachname"
                    value={formData.nachname}
                    onChange={handleChange}
                    placeholder="z.B. Mustermann"
                    className="rounded-xl border-2 bg-white dark:bg-gray-800 dark:border-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-primary focus:border-primary"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="position" className="text-gray-700 dark:text-gray-300">Position</Label>
                <Input
                  id="position"
                  name="position"
                  value={formData.position}
                  onChange={handleChange}
                  placeholder="z.B. Senior Projektmanager"
                  className="rounded-xl border-2 bg-white dark:bg-gray-800 dark:border-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-primary focus:border-primary"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="telefon" className="text-gray-700 dark:text-gray-300">Telefon</Label>
                  <Input
                    id="telefon"
                    name="telefon"
                    value={formData.telefon}
                    onChange={handleChange}
                    placeholder="+49 30 12345678"
                    className="rounded-xl border-2 bg-white dark:bg-gray-800 dark:border-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-primary focus:border-primary"
                    type="tel"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email" className="text-gray-700 dark:text-gray-300">E-Mail</Label>
                  <Input
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="max.mustermann@firma.de"
                    className="rounded-xl border-2 bg-white dark:bg-gray-800 dark:border-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-primary focus:border-primary"
                    type="email"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="notizen" className="text-gray-700 dark:text-gray-300">Notizen</Label>
                <Textarea
                  id="notizen"
                  name="notizen"
                  value={formData.notizen}
                  onChange={handleChange}
                  placeholder="Zusätzliche Informationen über den Projektleiter..."
                  className="rounded-xl border-2 bg-white dark:bg-gray-800 dark:border-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-primary focus:border-primary"
                  rows={4}
                />
              </div>
            </CardContent>
          </Card>

          {/* Aktionen */}
          <div className="flex justify-end space-x-4 mt-6">
            <Button type="button" asChild className="modern-button-secondary rounded-xl">
              <Link href={backUrl}>Abbrechen</Link>
            </Button>
            <Button 
              type="submit" 
              disabled={isLoading || !formData.vorname.trim() || !formData.nachname.trim() || !formData.firmaId}
              className="modern-button-primary rounded-xl"
            >
              {isLoading ? (
                <>
                  <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
                  Erstelle...
                </>
              ) : (
                <>
                  <Save className="mr-2 h-4 w-4" />
                  Projektleiter erstellen
                </>
              )}
            </Button>
          </div>
        </form>
      </div>
    </div>
  )
}

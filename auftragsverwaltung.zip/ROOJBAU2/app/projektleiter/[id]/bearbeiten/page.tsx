'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Toast } from '@/components/ui/toast'
import { ArrowLeft, Save, Trash2, User } from 'lucide-react'
import Link from 'next/link'

interface Projektleiter {
  id: string
  vorname: string
  nachname: string
  telefon?: string
  email?: string
  position?: string
  notizen?: string
  firma: {
    id: string
    name: string
  }
}

export default function ProjektleiterBearbeitenPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const queryClient = useQueryClient()
  const [isLoading, setIsLoading] = useState(false)
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null)
  const [formData, setFormData] = useState({
    vorname: '',
    nachname: '',
    telefon: '',
    email: '',
    position: '',
    notizen: ''
  })

  const { data: projektleiter, isLoading: isLoadingProjektleiter, error } = useQuery({
    queryKey: ['projektleiter', params.id],
    queryFn: async () => {
      const response = await fetch(`/api/projektleiter/${params.id}`)
      if (!response.ok) {
        throw new Error('Projektleiter nicht gefunden')
      }
      return response.json() as Promise<Projektleiter>
    }
  })

  useEffect(() => {
    if (projektleiter) {
      setFormData({
        vorname: projektleiter.vorname || '',
        nachname: projektleiter.nachname || '',
        telefon: projektleiter.telefon || '',
        email: projektleiter.email || '',
        position: projektleiter.position || '',
        notizen: projektleiter.notizen || ''
      })
    }
  }, [projektleiter])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      const response = await fetch(`/api/projektleiter/${params.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          vorname: formData.vorname.trim(),
          nachname: formData.nachname.trim(),
          telefon: formData.telefon.trim() || undefined,
          email: formData.email.trim() || undefined,
          position: formData.position.trim() || undefined,
          notizen: formData.notizen.trim() || undefined,
        }),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || 'Fehler beim Aktualisieren des Projektleiters')
      }

      const updatedProjektleiter = await response.json()
      
      // Invalidate queries to refresh data
      queryClient.invalidateQueries({ queryKey: ['projektleiter', params.id] })
      queryClient.invalidateQueries({ queryKey: ['firma', projektleiter?.firma.id] })
      queryClient.invalidateQueries({ queryKey: ['firmen'] })
      
      // Success message
      setToast({ message: 'Projektleiter wurde erfolgreich aktualisiert!', type: 'success' })
      
      // Navigate back after a short delay
      setTimeout(() => {
        router.push(`/firmen/${projektleiter?.firma.id}/bearbeiten`)
      }, 2000)
      
    } catch (error) {
      console.error('Fehler beim Aktualisieren des Projektleiters:', error)
      setToast({ 
        message: `Fehler: ${error instanceof Error ? error.message : 'Unbekannter Fehler'}`, 
        type: 'error' 
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleDelete = async () => {
    if (!confirm('Sind Sie sicher, dass Sie diesen Projektleiter löschen möchten? Diese Aktion kann nicht rückgängig gemacht werden.')) {
      return
    }

    setIsLoading(true)

    try {
      const response = await fetch(`/api/projektleiter/${params.id}`, {
        method: 'DELETE',
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || 'Fehler beim Löschen des Projektleiters')
      }

      // Invalidate queries
      queryClient.invalidateQueries({ queryKey: ['firma', projektleiter?.firma.id] })
      queryClient.invalidateQueries({ queryKey: ['firmen'] })
      
      setToast({ message: 'Projektleiter wurde erfolgreich gelöscht!', type: 'success' })
      
      // Navigate back after a short delay
      setTimeout(() => {
        router.push(`/firmen/${projektleiter?.firma.id}/bearbeiten`)
      }, 2000)
      
    } catch (error) {
      console.error('Fehler beim Löschen des Projektleiters:', error)
      setToast({ 
        message: `Fehler beim Löschen: ${error instanceof Error ? error.message : 'Unbekannter Fehler'}`, 
        type: 'error' 
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData(prev => ({ ...prev, [name]: value }))
  }

  if (isLoadingProjektleiter) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gradient-to-br dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 transition-colors duration-300 p-6">
        <div className="flex items-center space-x-4 mb-8">
          <div className="h-10 w-20 bg-gray-200 dark:bg-gray-700 rounded-xl animate-pulse"></div>
          <div className="h-8 w-48 bg-gray-200 dark:bg-gray-700 rounded-xl animate-pulse"></div>
        </div>
        <div className="max-w-2xl">
          <Card className="dark-card-modern animate-pulse">
            <CardHeader>
              <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded w-1/3 mb-2"></div>
              <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-1/2"></div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[...Array(6)].map((_, i) => (
                  <div key={i} className="space-y-2">
                    <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-1/4"></div>
                    <div className="h-10 bg-gray-200 dark:bg-gray-700 rounded"></div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  if (error || !projektleiter) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gradient-to-br dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 transition-colors duration-300 p-6">
        <div className="flex items-center space-x-4 mb-8">
          <Button variant="ghost" size="sm" asChild className="text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800">
            <Link href="/firmen">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Zurück
            </Link>
          </Button>
        </div>
        <Card className="dark-card-modern">
          <CardContent className="pt-6 text-center">
            <h3 className="text-lg font-medium mb-2 text-gray-900 dark:text-white">Projektleiter nicht gefunden</h3>
            <p className="text-gray-600 dark:text-gray-400 mb-4">Der angeforderte Projektleiter konnte nicht geladen werden.</p>
            <Button asChild className="modern-button-primary">
              <Link href="/firmen">Zurück zu Firmen</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gradient-to-br dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 transition-colors duration-300 p-6">
      {/* Toast */}
      {toast && (
        <Toast 
          message={toast.message} 
          type={toast.type} 
          onClose={() => setToast(null)} 
        />
      )}

      {/* Header */}
      <div className="flex items-center space-x-4 mb-8">
        <Button variant="ghost" size="sm" asChild className="text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800">
          <Link href={`/firmen/${projektleiter.firma.id}/bearbeiten`}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Zurück zu {projektleiter.firma.name}
          </Link>
        </Button>
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
            Projektleiter bearbeiten
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            {projektleiter.vorname} {projektleiter.nachname} von {projektleiter.firma.name}
          </p>
        </div>
      </div>

      {/* Formular */}
      <div className="max-w-2xl mx-auto">
        <form onSubmit={handleSubmit}>
          <Card className="dark-card-modern">
            <CardHeader>
              <CardTitle className="flex items-center text-xl text-gray-900 dark:text-white">
                <div className="fintech-kpi-card p-2 neon-glow-blue mr-3">
                  <User className="h-5 w-5 text-white" />
                </div>
                Projektleiter-Informationen
              </CardTitle>
              <CardDescription className="text-gray-600 dark:text-gray-400">
                Bearbeiten Sie die Informationen des Projektleiters
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="vorname" className="text-gray-700 dark:text-gray-300">Vorname *</Label>
                  <Input
                    id="vorname"
                    name="vorname"
                    value={formData.vorname}
                    onChange={handleChange}
                    placeholder="z.B. Max"
                    className="rounded-xl border-2 bg-white dark:bg-gray-800 dark:border-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-primary focus:border-primary"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="nachname" className="text-gray-700 dark:text-gray-300">Nachname *</Label>
                  <Input
                    id="nachname"
                    name="nachname"
                    value={formData.nachname}
                    onChange={handleChange}
                    placeholder="z.B. Mustermann"
                    className="rounded-xl border-2 bg-white dark:bg-gray-800 dark:border-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-primary focus:border-primary"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="position" className="text-gray-700 dark:text-gray-300">Position</Label>
                <Input
                  id="position"
                  name="position"
                  value={formData.position}
                  onChange={handleChange}
                  placeholder="z.B. Senior Projektmanager"
                  className="rounded-xl border-2 bg-white dark:bg-gray-800 dark:border-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-primary focus:border-primary"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="telefon" className="text-gray-700 dark:text-gray-300">Telefon</Label>
                  <Input
                    id="telefon"
                    name="telefon"
                    value={formData.telefon}
                    onChange={handleChange}
                    placeholder="+49 30 12345678"
                    className="rounded-xl border-2 bg-white dark:bg-gray-800 dark:border-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-primary focus:border-primary"
                    type="tel"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email" className="text-gray-700 dark:text-gray-300">E-Mail</Label>
                  <Input
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="max.mustermann@firma.de"
                    className="rounded-xl border-2 bg-white dark:bg-gray-800 dark:border-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-primary focus:border-primary"
                    type="email"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="notizen" className="text-gray-700 dark:text-gray-300">Notizen</Label>
                <Textarea
                  id="notizen"
                  name="notizen"
                  value={formData.notizen}
                  onChange={handleChange}
                  placeholder="Zusätzliche Informationen über den Projektleiter..."
                  className="rounded-xl border-2 bg-white dark:bg-gray-800 dark:border-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-primary focus:border-primary"
                  rows={4}
                />
              </div>
            </CardContent>
          </Card>

          {/* Aktionen */}
          <div className="flex justify-between mt-6">
            <Button 
              variant="destructive" 
              type="button" 
              onClick={handleDelete}
              disabled={isLoading}
              className="rounded-xl"
            >
              <Trash2 className="mr-2 h-4 w-4" />
              Projektleiter löschen
            </Button>
            
            <div className="flex space-x-4">
              <Button type="button" asChild className="modern-button-secondary rounded-xl">
                <Link href={`/firmen/${projektleiter.firma.id}/bearbeiten`}>Abbrechen</Link>
              </Button>
              <Button 
                type="submit" 
                disabled={isLoading || !formData.vorname.trim() || !formData.nachname.trim()}
                className="modern-button-primary rounded-xl"
              >
                {isLoading ? (
                  <>
                    <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
                    Speichere...
                  </>
                ) : (
                  <>
                    <Save className="mr-2 h-4 w-4" />
                    Änderungen speichern
                  </>
                )}
              </Button>
            </div>
          </div>
        </form>
      </div>
    </div>
  )
}

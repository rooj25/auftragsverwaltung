# PRD - Auftragsverwaltungs-Anwendung für Subunternehmen

## Projektübersicht
Eine professionelle Web-Anwendung zur effizienten Verwaltung von Aufträgen verschiedener Firmen für ein Subunternehmen.

## Funktionale Anforderungen

### ✅ Abgeschlossen
- [x] PRD-Dokumentation erstellt
- [x] Anforderungsanalyse durchgeführt

### 🔄 In Bearbeitung
- [ ] Technologie-Stack Definition
- [ ] Datenbank-Schema Design

### 📋 Geplante Funktionen

#### 1. Firmenverwaltung
- [ ] **Firma hinzufügen**
  - Firmenname
  - Kontaktinformationen
  - Adresse
  - Notizen/Beschreibung
  
- [ ] **Projektleiter verwalten**
  - Name und Nachname
  - Telefonnummer
  - E-Mail-Adresse
  - Notizen über den Projektleiter
  - Zuordnung zur Firma

- [ ] **Firmendetails anzeigen**
  - Vollständige Firmeninformationen
  - Liste aller zugeordneten Projektleiter
  - Übersicht aller Aufträge der Firma
  
- [ ] **Firma bearbeiten/aktualisieren**
  - Alle Firmeninformationen editierbar
  - Projektleiter hinzufügen/entfernen/bearbeiten

#### 2. Auftragsverwaltung
- [ ] **Auftrag erstellen**
  - Auftragsnummer (automatisch generiert)
  - Auftragstitel/Beschreibung
  - Zuordnung zur Firma
  - Zuordnung zum Projektleiter
  - Startdatum
  - Geplantes Enddatum
  - Status (Neu, In Bearbeitung, Abgeschlossen, Storniert)
  - Priorität (Niedrig, Normal, Hoch, Kritisch)
  - Detaillierte Beschreibung
  - Geschätzter Aufwand
  - Tatsächlicher Aufwand
  
- [ ] **Auftragsdetails anzeigen**
  - Vollständige Auftragsinformationen
  - Zugehörige Firma und Projektleiter
  - Statusverlauf/Timeline
  
- [ ] **Auftrag bearbeiten/aktualisieren**
  - Alle Auftragsfelder editierbar
  - Status-Updates mit Zeitstempel
  - Kommentare/Notizen hinzufügen

#### 3. Dashboard und Übersichten
- [ ] **Haupt-Dashboard**
  - Übersicht aktuelle Aufträge
  - Status-Statistiken
  - Anstehende Deadlines
  - Firmen-Übersicht
  
- [ ] **Listen-Ansichten**
  - Filterable Firmenliste
  - Filterable Auftragsliste
  - Sortierung nach verschiedenen Kriterien
  - Suchfunktion

#### 4. Benutzeroberfläche
- [ ] **Responsive Design**
  - Desktop-optimiert
  - Tablet-kompatibel
  - Mobile-freundlich
  
- [ ] **Moderne UI/UX**
  - Intuitive Navigation
  - Professionelles Design
  - Schnelle Ladezeiten
  - Benutzerfreundliche Formulare

#### 5. Datenmanagement
- [ ] **Datenbank-Integration**
  - Sichere Datenspeicherung
  - Datenintegrität
  - Backup-Mechanismen
  
- [ ] **Import/Export**
  - CSV-Export für Berichte
  - Daten-Backup-Funktionen

## Technische Anforderungen

### Frontend
- [ ] React/Next.js Framework
- [ ] TypeScript für Type Safety
- [ ] Tailwind CSS für Styling
- [ ] React Hook Form für Formular-Management
- [ ] React Query für Server State Management

### Backend
- [ ] Node.js mit Express/Fastify
- [ ] TypeScript
- [ ] Prisma ORM für Datenbank-Management
- [ ] SQLite/PostgreSQL Datenbank

### Entwicklungstools
- [ ] ESLint und Prettier für Code-Qualität
- [ ] Husky für Git Hooks
- [ ] Jest für Testing

## Benutzer-Stories

### Als Subunternehmer möchte ich:
1. **Neue Firmen hinzufügen** können, um meine Kunden zu verwalten
2. **Projektleiter zu Firmen zuordnen** können, um klare Ansprechpartner zu haben
3. **Aufträge erstellen und verwalten** können, um den Überblick zu behalten
4. **Auftrags-Status aktualisieren** können, um den Fortschritt zu verfolgen
5. **Firmen- und Auftragsdetails einsehen** können, um schnell Informationen zu finden
6. **Alle Daten bearbeiten** können, um Änderungen zu berücksichtigen
7. **Eine übersichtliche Dashboard-Ansicht** haben, um wichtige Informationen auf einen Blick zu sehen

## Akzeptanzkriterien

### Firmenverwaltung
- ✅ Neue Firma kann mit allen erforderlichen Feldern hinzugefügt werden
- ✅ Projektleiter können zur Firma hinzugefügt werden (Name, Nachname, Telefon, Notizen)
- ✅ Firmendetails sind vollständig einsehbar
- ✅ Alle Firmeninformationen sind bearbeitbar
- ✅ Projektleiter-Informationen sind bearbeitbar

### Auftragsverwaltung
- ✅ Neue Aufträge können erstellt und einer Firma zugeordnet werden
- ✅ Auftragsdetails sind vollständig einsehbar
- ✅ Auftrags-Status kann aktualisiert werden
- ✅ Alle Auftragsinformationen sind bearbeitbar
- ✅ Aufträge können nach verschiedenen Kriterien gefiltert werden

### Benutzeroberfläche
- ✅ Anwendung ist responsive und funktioniert auf allen Geräten
- ✅ Navigation ist intuitiv und benutzerfreundlich
- ✅ Ladezeiten sind akzeptabel (< 3 Sekunden)
- ✅ Design ist professionell und modern

## Zeitplan
- **Phase 1**: Setup und Grundstruktur (Tag 1)
- **Phase 2**: Datenbank und Backend API (Tag 1-2)
- **Phase 3**: Frontend-Komponenten (Tag 2-3)
- **Phase 4**: Integration und Testing (Tag 3)
- **Phase 5**: Deployment und Dokumentation (Tag 3)

## Erfolgsmetriken
- Alle CRUD-Operationen funktionieren fehlerfrei
- Benutzeroberfläche ist intuitiv bedienbar
- Anwendung lädt schnell und ist stabil
- Alle Anforderungen sind implementiert und getestet

---

*Dieses Dokument wird während der Entwicklung kontinuierlich aktualisiert, um den Fortschritt zu dokumentieren.*

